#pragma once
#include <memory>
#include <stdexcept>

class Crypt_error: public std::runtime_error {
    public:
        explicit Crypt_error(const std::string& what_arg): std::runtime_error(what_arg){
            // Nothing to do here.
        }
};

class Crypt{
    private:
        unsigned char* current_state;
        size_t size;

    public:
        Crypt(const unsigned char* input, size_t input_size);
        std::shared_ptr<unsigned char> get();
        size_t get_size();

        void encrypt(const unsigned char* key, size_t key_size, unsigned int seed);
        void decrypt(const unsigned char* key, size_t key_size, unsigned int seed);
};

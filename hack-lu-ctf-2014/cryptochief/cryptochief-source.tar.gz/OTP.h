// This implements the super secure OTP!1111
#include <memory>
#include <stdexcept>
#include <string>

#pragma once

class OTP_error: public std::runtime_error {
    public:
        explicit OTP_error(const std::string& what_arg): std::runtime_error(what_arg){
            // Nothing to do here.
        }
};

class OTP {
    private:
        const unsigned char* key;
        size_t key_pos;
        size_t key_size;

    public:
        OTP(const unsigned char* key, size_t size):key(key), key_pos(0), key_size(size){
            if(key == nullptr)
                throw OTP_error("OTP can not be initialized using an empty key.");
        };

        std::shared_ptr<unsigned char> encrypt(const unsigned char* input, size_t size);
        std::shared_ptr<unsigned char> decrypt(const unsigned char* input, size_t size);
};

#include "OTP.h"

std::shared_ptr<unsigned char> OTP::encrypt(const unsigned char* input, size_t size){
    return this -> decrypt(input, size);
}

std::shared_ptr<unsigned char> OTP::decrypt(const unsigned char* input, size_t size){
    // Check for key material
    if((this -> key_size - this -> key_pos) < size)
        throw OTP_error("Not enough keystream available.");

    // Check for nullptr
    if(input == nullptr)
        throw OTP_error("Invalid input argument");

    // Allocate memory
    std::shared_ptr<unsigned char> buffer(new unsigned char[size]);

    // Do the actual crypto
    for(size_t i = 0; i < size; i++)
        buffer.get()[i] = input[i] ^ this -> key[this -> key_pos++];

    return buffer;
}


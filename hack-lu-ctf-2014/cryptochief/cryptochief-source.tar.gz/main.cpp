#include <iostream>
#include <ctype.h>
#include <stdio.h>
#include <cstring>
#include <fstream>

#include <windows.h>

#include "OTP.h"
#include "LBV_N_DW.h"
#include "KeyGenerator.h"
#include "Crypt.h"

#define IDD_DLG_MAIN 1001
#define IDC_BTN_DO_HASH 1002
#define IDC_TXT_HASH_INPUT 1003
#define IDC_BTN_DATA_DECRYPT 1005
#define IDC_BTN_DATA_ENCRYPT 1004
#define IDC_BTN_CREATE_KEY_DATA 1006
#define IDC_BTN_DESTROY_DATA 1007
#define IDC_BTN_DATA_PASSWORD_ENCRYPTION 1008
#define IDC_BTN_DATA_PASSWORD_DECRYPTION 1009
#define ICO_APP 1337

#define BMP_BG 9000
#define IDC_BG_IMG 9001

HBITMAP background;



INT_PTR CALLBACK windowHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int main(int argc, char const *argv[]){
    DialogBoxParam(NULL, MAKEINTRESOURCE(1001), 0, windowHandler, 0);
    return 0;
}

std::shared_ptr<unsigned char> select_and_open_file(HWND hWnd, const char* title, const char* filter, unsigned long* o_size){
    OPENFILENAME ofn;
    char szFile[260];
    char* filename;

    // Initialize OPENFILENAME
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hWnd;
    ofn.lpstrFile = szFile;
    ofn.lpstrFile[0] = '\0';
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = title;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
    if (!GetOpenFileName(&ofn)){
        MessageBox(hWnd, "Could not open file", "Meh", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not open file");
    }

    filename = ofn.lpstrFile;

    HANDLE hF;

    hF = CreateFile(filename, 
        GENERIC_READ,
        0,
        (LPSECURITY_ATTRIBUTES) NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        (HANDLE) NULL);

    if(hF == INVALID_HANDLE_VALUE){
        MessageBoxA(hWnd, "Could not open file", "ERROR", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not open file");
    }

    unsigned long size = GetFileSize(hF, nullptr);

    *o_size = size;

    std::shared_ptr<unsigned char> txt(nullptr);
    try{
        txt = std::shared_ptr<unsigned char>(new unsigned char[size]);
    } catch (std::bad_alloc& ba){
        MessageBoxA(hWnd, "Out of memory", "Error", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Out of memory");
    }

    unsigned long bytes_read;
    if(!ReadFile(hF, (char*)txt.get(), size, &bytes_read, NULL) || bytes_read != size){
        MessageBox(hWnd, "Reading the whole file failed", "Meh", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not read file");
    }

    CloseHandle(hF);

    return txt;
}

void select_and_write_file(HWND hWnd, const char* title, const char* filter, const unsigned char* content, unsigned long size){
    OPENFILENAME ofn;
    char szFile[260];
    char* filename;

    // Initialize OPENFILENAME
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hWnd;
    ofn.lpstrFile = szFile;
    ofn.lpstrFile[0] = '\0';
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = title;
    ofn.Flags = OFN_PATHMUSTEXIST;
    if (!GetOpenFileName(&ofn)){
        MessageBox(hWnd, "Could not open file", "Meh", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not open file");
    }

    filename = ofn.lpstrFile;

    HANDLE hF;

    hF = CreateFile(filename, 
        GENERIC_WRITE,
        0,
        (LPSECURITY_ATTRIBUTES) NULL,
        OPEN_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        (HANDLE) NULL);

    if(hF == INVALID_HANDLE_VALUE){
        MessageBoxA(hWnd, "Could not open file", "ERROR", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not open file");
    }

    unsigned long bytes_written;
    if(!WriteFile(hF, content, size, &bytes_written, NULL) || bytes_written != size){
        MessageBox(hWnd, "Writing the whole file failed", "Meh", MB_OK | MB_ICONERROR);
        throw std::runtime_error("Could not read file");
    }

    CloseHandle(hF);
}

INT_PTR CALLBACK windowHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam){
    switch(uMsg){
        case WM_INITDIALOG:
            SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(NULL, MAKEINTRESOURCE(1337)));
            SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LoadIcon(NULL, MAKEINTRESOURCE(1337)));
            background = (HBITMAP)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(BMP_BG), IMAGE_BITMAP, 0, 0, 0);
            if(!background){
                std::cout << "Setting image failed " << GetLastError() << std::endl;
            }
            SendMessage(GetDlgItem(hWnd, IDC_BG_IMG), STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)background);
            return 1;
        break;
        case WM_CLOSE:
            PostMessage(hWnd, WM_QUIT, 0, 0);
        break;

        case WM_COMMAND:{
            switch(LOWORD(wParam)){
                case IDC_BTN_DATA_DECRYPT:
                    MessageBox(hWnd, "Please buy the Professional Ultimate Unlimited Special Extended version to use this mode.", "Gimme cash", MB_OK | MB_ICONERROR);
                break;
                case IDC_BTN_DATA_ENCRYPT:
                    MessageBox(hWnd, "Please buy the Professional Ultimate Unlimited Special Extended version to use this mode.", "Gimme cash", MB_OK | MB_ICONERROR);
                break;
                case IDC_BTN_CREATE_KEY_DATA:
                    MessageBox(hWnd, "Keyfile created", "!! DONE !!", MB_OK | MB_ICONINFORMATION);
                break;
                case IDC_BTN_DESTROY_DATA:
                    MessageBox(hWnd, "Data successfully destroyed", "!! DONE !!", MB_OK | MB_ICONINFORMATION);
                break;
                case IDC_BTN_DATA_PASSWORD_ENCRYPTION:{
                    try{
                        unsigned long plain_length, key_length;
                        std::shared_ptr<unsigned char> plaintext(select_and_open_file(hWnd, "File to encrypt", "ALL\0*.*\0", &plain_length));
                        std::shared_ptr<unsigned char> keyfile(select_and_open_file(hWnd, "Keyfile", "Keyfile\0*.key\0ALL\0*.*\0", &key_length));

                        Crypt crypt(plaintext.get(), plain_length);
                        crypt.encrypt(keyfile.get(), key_length, 0x1337CAFE);

                        select_and_write_file(hWnd, "Output file", "KRYPTO-File\0*.krypto\0ALL\0*.*\0", crypt.get().get(), crypt.get_size());
                    } catch(std::runtime_error& e){
                        std::cerr << "Exception: " << e.what() << std::endl;
                    }
                } break;
                case IDC_BTN_DATA_PASSWORD_DECRYPTION:{
                    try{
                        unsigned long cipher_length, key_length;
                        std::shared_ptr<unsigned char> ciphertext(select_and_open_file(hWnd, "File to decrypt", "KRYPTO\0*.KRYPTO\0ALL\0*.*\0", &cipher_length));
                        std::shared_ptr<unsigned char> keyfile(select_and_open_file(hWnd, "Keyfile", "Keyfile\0*.key\0ALL\0*.*\0", &key_length));

                        Crypt crypt(ciphertext.get(), cipher_length);
                        crypt.decrypt(keyfile.get(), key_length, 0x1337CAFE);

                        select_and_write_file(hWnd, "Output file", "ALL\0*.*\0", crypt.get().get(), crypt.get_size());
                    } catch(std::runtime_error& e){
                        std::cerr << "Exception: " << e.what() << std::endl;
                    }
                } break;
            }
        } break;
        default:
            return 0;
        break;
    }
    return 0;
}


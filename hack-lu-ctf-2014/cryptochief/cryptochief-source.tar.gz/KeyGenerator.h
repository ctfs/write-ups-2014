// This is the very trustworthy key generation class
#include <memory>
#include <stdexcept>
#include <string>
#include "LBV_N_DW.h"

#pragma once

class KeyGenerator_error: public std::runtime_error {
    public:
        explicit KeyGenerator_error(const std::string& what_arg): std::runtime_error(what_arg){
            // Nothing to do here.
        }
};

class KeyGenerator {
    private:
        std::shared_ptr<unsigned char> current_state;
        std::shared_ptr<LBV_N_DW> hashalgo;
        size_t key_size;
        size_t round;
        void calculate();
    public:
        KeyGenerator(const unsigned char* base_key, size_t base_key_size, size_t required_key_size);
        ~KeyGenerator(){}

        std::shared_ptr<unsigned char> get_next_key();
        std::shared_ptr<unsigned char> get_N_bytes(unsigned long N);

        size_t get_key_size(){
            return this -> key_size;
        }
};

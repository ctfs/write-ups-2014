// By Dieter Woznarg (original)
#include <memory>
#include <stdexcept>
#include <string>

#pragma once

class LBV_N_DW_Error: public std::runtime_error {
    public:
        explicit LBV_N_DW_Error(const std::string& what_arg): std::runtime_error(what_arg){
            // Nothing to do here.
        }
};

class LBV_N_DW {
    private:
        const unsigned short depth;

    public:
        LBV_N_DW(unsigned short hash_depth): depth(hash_depth){};

        size_t get_hash_size();

        std::shared_ptr<unsigned char> hash(const unsigned char* input, size_t input_size);
};

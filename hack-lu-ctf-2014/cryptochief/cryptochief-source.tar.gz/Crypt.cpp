#include "Crypt.h"
#include "KeyGenerator.h"
#include "OTP.h"
#include <time.h>
#include <string>
#include <cstring>
#include <iostream>
const std::string cryptochief_secret_string = 
    "Secret Cryptochief Password. The only uncrackable fullbit encryption by "
    "Dieter Woznarg (original). Nobody would ever guess this super secret "
    "string so this is perfectly secure. "
    "Especially the NSA can't crack this. Even I can't do that! "
    "Kryptochef has no chance against my super program. He's afraid and even "
    "deleted his homepage.";

bool generate_random_buffer(unsigned char* buffer, size_t size, unsigned int seed){
    if(size == 0 || buffer == nullptr)
        return false;

    srand(seed);
    for(size_t i = 0; i < size; i++){
        buffer[i] = rand() & 0xFF;
    }
    return true;
}

Crypt::Crypt(const unsigned char* input, size_t input_size){
    if(input == nullptr)
        throw Crypt_error("Invalid input buffer");

    if(input_size == 0)
        throw Crypt_error("Invalid input buffer size");

    try{
        this -> current_state = new unsigned char[input_size];
    } catch(std::bad_alloc& ba){
        throw Crypt_error("Out of memory");
    }

    memcpy(this -> current_state, input, input_size);

    this -> size = input_size;
}

std::shared_ptr<unsigned char> Crypt::get(){
    unsigned char* buf = nullptr;
    try{
        buf = new unsigned char[this -> size];
    } catch(std::bad_alloc& ba){
        throw Crypt_error("Out of memory");
    }

    memcpy(buf, this -> current_state, this -> size);
    return std::shared_ptr<unsigned char>(buf);
}

size_t Crypt::get_size(){
    return this -> size;
}


/*
1. Verschlüsselung: Aus ihrem Passwort wird intern eine Passwort Schlüsseldatei berechnet.
2. Verschlüsselung: Diese Schlüsseldatei wird mit einem Verschlüsselungs Algorithmus welcher nur in KRYPTO ist,
                    per Vollbit verschlüsselt.
3. Verschlüsselung: Danach wird diese Schlüsseldatei mit ein nur in KRYPTO intern enthaltene geheime erechnete
                    Passwort Datei Vollbit verschlüsselt.
                    Dies ist nicht die Passwort Schlüsseldatei aus der 1.Verschlüsselung.
4. Verschlüsselung: Danach wird die Original Datei mit der Schlüsseldatei Vollbit verschlüsselt.
5. Verschlüsselung: Danach wird die verschlüsselte Datei nocheinmal, aber diesmal per Zufall Vollbit verschlüsselt.
                    Erst jetzt wird die verschlüsselte Datei gespeichert.
 */
void Crypt::encrypt(const unsigned char* key, size_t key_size, unsigned int seed){
    if(key == nullptr)
        throw Crypt_error("Invalid key buffer");

    if(key_size == 0)
        throw Crypt_error("Invalid key buffer size");

    // Do the special 5 times encryption
    // First and second step: Generate a password out of the key.
    KeyGenerator key_generator(key, key_size, 8);
    std::shared_ptr<unsigned char> random = key_generator.get_N_bytes((this -> size / 4)*4 + 4);

    OTP otp(random.get(), (this -> size / 4)*4 + 4);
    std::shared_ptr<unsigned char> stage_1 = otp.encrypt(this -> current_state, this -> size);

    // Third and forth step: Do the same but with the secret cryptochief internal special awesome key.
    std::string tmp = cryptochief_secret_string;
    while(tmp.length() < this -> size)
        tmp += cryptochief_secret_string;

    OTP otp_3((const unsigned char*)tmp.c_str(), tmp.length());
    std::shared_ptr<unsigned char> stage_2 = otp_3.encrypt(stage_1.get(), this -> size);

    // Last step: Generate random and encrypt it again!
    std::shared_ptr<unsigned char> rnd(new unsigned char[this -> size]);
    if(!generate_random_buffer(rnd.get(), this -> size, seed))
        throw Crypt_error("Unable to generate random.");

    OTP otp_5(rnd.get(), this -> size);
    std::shared_ptr<unsigned char> stage_3 = otp_5.encrypt(stage_2.get(), this -> size);

    // Now the data is secure!
    memcpy(this -> current_state, stage_3.get(), this -> size);
}

void Crypt::decrypt(const unsigned char* key, size_t key_size, unsigned int seed){
    if(key == nullptr)
        throw Crypt_error("Invalid key buffer");

    if(key_size == 0)
        throw Crypt_error("Invalid key buffer size");

    // Do the special 5 times encryption
    // Last step: Generate random and encrypt it again!
    std::shared_ptr<unsigned char> rnd(new unsigned char[this -> size]);
    if(!generate_random_buffer(rnd.get(), this -> size, seed))
        throw Crypt_error("Unable to generate random.");

    OTP otp_5(rnd.get(), this -> size);
    std::shared_ptr<unsigned char> stage_3 = otp_5.decrypt(this -> current_state, this -> size);

    // Third and forth step: Do the same but with the secret cryptochief internal special awesome key.
        std::string tmp = cryptochief_secret_string;
    while(tmp.length() < this -> size)
        tmp += cryptochief_secret_string;
    OTP otp_3((const unsigned char*)tmp.c_str(), tmp.length());
    std::shared_ptr<unsigned char> stage_2 = otp_3.decrypt(stage_3.get(), this -> size);

    // First and second step: Generate a password out of the key.
    KeyGenerator key_generator(key, key_size, 8);
    std::shared_ptr<unsigned char> random = key_generator.get_N_bytes((this -> size / 4)*4 + 4);
    //std::shared_ptr<unsigned char> random = key_generator.get_next_key();

    OTP otp(random.get(), (this -> size / 4)*4 + 4);
    std::shared_ptr<unsigned char> stage_1 = otp.encrypt(stage_2.get(), this -> size);



    // Now the data is secure!
    memcpy(this -> current_state, stage_1.get(), this -> size);
}

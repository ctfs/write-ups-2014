#include "KeyGenerator.h"
#include <cstring>

#include <iostream>

#include <ctype.h>
#include <stdio.h>

void KeyGenerator::calculate(){
    // It nearly took 2 years but now I have the ultimate formula for key derivation:
    // Just hash the hash again :) BRILLIANT! Of course my idea!1 Don't steal it.
    for(size_t i = 0; i < this -> key_size; i++){
        this -> current_state.get()[i]+= (i % this -> round);
        if(this -> round % 2)
            this -> current_state.get()[i] = ~this -> current_state.get()[i];
    }

    std::shared_ptr<unsigned char> hash = this -> hashalgo -> hash((const unsigned char*)this -> current_state.get(), this -> key_size);
    memcpy(this -> current_state.get(), hash.get(), this -> key_size);

    this -> round++;
}

KeyGenerator::KeyGenerator(const unsigned char* base_key, size_t base_key_size, size_t minimum_key_size): 
    current_state(new unsigned char[minimum_key_size]), 
    hashalgo(new LBV_N_DW(minimum_key_size/4)),
    key_size(minimum_key_size){

    // We use LBV_N_DW internally, so we only can create sizes multiples by 4.
    if(minimum_key_size == 0)
        throw KeyGenerator_error("Can't create keys with size 0");

    if(minimum_key_size % 4)
        throw KeyGenerator_error("Keysize must be multiple of 4");

    if(base_key == nullptr)
        throw KeyGenerator_error("No base key supplied");

    if(this -> current_state.get() == nullptr)
        throw KeyGenerator_error("Out of memory");

    if(this -> hashalgo.get() == nullptr)
        throw KeyGenerator_error("Out of memory");

    this -> round = 1;

    // Generate initial state using the fullbit hashing method LBV_N_DW (original)
    std::shared_ptr<unsigned char> hash = this -> hashalgo -> hash((const unsigned char*)base_key, base_key_size);
    memcpy(this -> current_state.get(), hash.get(), this -> key_size);
}

std::shared_ptr<unsigned char> KeyGenerator::get_next_key(){
    std::shared_ptr<unsigned char> key(new unsigned char[this -> key_size]);
    if(!key.get())
        throw KeyGenerator_error("Out of memory");

    this -> calculate();

    memcpy(key.get(), this -> current_state.get(), this -> key_size);

    return key;
}

std::shared_ptr<unsigned char> KeyGenerator::get_N_bytes(unsigned long N){
    // Calculate buffer size
    unsigned long no_rounds  = (N / this -> key_size) + 1;
    size_t b_size = no_rounds * this -> key_size;
    std::shared_ptr<unsigned char> key(new unsigned char[b_size]);

    for(unsigned long i = 0; i < no_rounds; i++){
        this -> calculate();
        memcpy(key.get() + i * this -> key_size, this -> current_state.get(), this -> key_size);
    }

    return key;
}

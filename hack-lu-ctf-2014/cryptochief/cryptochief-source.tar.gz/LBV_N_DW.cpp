#include "LBV_N_DW.h"

#include <cstring>
#include <cstdlib>
#include <iostream>

#define O1(a, b) ((a)|(b))
#define O2(a, b) ((a)&(b))
#define O3(a, b) ((~(a))^(b))
#define O4(a, b) ((a)^(~(b)))

#define M1(a) (a)
#define M2(a) (~a)
#define M3(a) (((a)>>8) | ((a) << 24))
#define M4(a) (((a)>>16) | ((a) << 16))
#define M5(a) (((a)>>24) | ((a) << 8))
#define M6(a) ((a) ^ 0x1337CAFE)
#define M7(a) ((a) | 0xDEADBEEF)
#define M8(a) ((a) | 0xB000B135)

#define C1(a, b) (O1(M1(a), M2(b)))
#define C2(a, b) (O3(M8(a), M4(b)))
#define C3(a, b) (O4(M2(a), M6(b)))
#define C4(a, b) (O2(M7(a), M8(b)))
#define C5(a, b) (O1(M3(a), M1(b)))
#define C6(a, b) (O1(M6(a), M3(b)))
#define C7(a, b) (O3(M4(a), M5(b)))
#define C8(a, b) (O4(M5(a), M7(b)))

#define X1(a, b) (C1(a, b) + C2(b, a) - (C3(a, b) ^ C4(b, a)))
#define X2(a, b) (C5(a, b) + C6(b, a) - (C7(a, b) ^ C8(b, a)))
#define X3(a, b) (C1(a, b) + C3(b, a) - (C5(a, b) ^ C7(b, a)))
#define X4(a, b) (C2(a, b) + C4(b, a) - (C6(a, b) ^ C8(b, a)))

#define WORD_TO_BYTE(x) (((x)>>8) | ((x) & 0xFF))
#define DWORD_TO_BYTE(x) (WORD_TO_BYTE((x)>>16) | WORD_TO_BYTE(x & 0xFFFF))

size_t LBV_N_DW::get_hash_size(){
    return this -> depth*4;
}

std::shared_ptr<unsigned char> LBV_N_DW::hash(const unsigned char* input, size_t input_size){
    // The hashsize is 4 times the depth
    std::shared_ptr<unsigned char> hash(new unsigned char[this -> depth*4]);
    uint32_t* p = (uint32_t*)hash.get();

    if(!input)
        throw LBV_N_DW_Error("Invalid input");

    srand(input_size | (input[0] << 8) | (input[input_size-1] << 16));

    // Fill the initial hash state with a "random" state
    for(size_t i = 0; i < this -> depth*4; i++)
        hash.get()[i] = DWORD_TO_BYTE(rand());

    for(size_t i = 0; i < input_size; i += 1){
        // Combine current state + input:
        // 1337 is a cool number so lets use it :)
        
        for(int n = 0; n < 1337; n++){
            for(size_t ii = 0; ii < this -> depth/4; ii++){
                p[ii] ^= input[i]; 
                /*
                // Removed, would have been too hard
                
                switch((input[n % input_size]+n)%8){
                    case 0: p[ii] = X1(p[ii], input[n % input_size]); break;
                    case 1: p[ii] = X2(p[ii], input[n % input_size]); break;
                    case 2: p[ii] = X3(p[ii], input[n % input_size]); break;
                    case 3: p[ii] = X4(p[ii], input[n % input_size]); break;
                    case 4: p[ii] = C5(p[ii], input[n % input_size]); break;
                    case 5: p[ii] = C6(p[ii], input[n % input_size]); break;
                    case 6: p[ii] = C7(p[ii], input[n % input_size]); break;
                    case 7: p[ii] = C8(p[ii], input[n % input_size]); break;
                }
                */
            }
        }

        // Do the "rounds"
        for(unsigned short iteration = 0; iteration < this -> depth; iteration++){
            // Iterate over each position
            for(unsigned short x = 0; x < this -> depth/2; x++){
                switch(x%8){
                    case 0: p[x] = C1(p[x], p[x+1]); break;
                    case 1: p[x] = C2(p[x], p[x+1]); break;
                    case 2: p[x] = C3(p[x], p[x+1]); break;
                    case 3: p[x] = C4(p[x], p[x+1]); break;
                    case 4: p[x] = C5(p[x], p[x+1]); break;
                    case 5: p[x] = C6(p[x], p[x+1]); break;
                    case 6: p[x] = C7(p[x], p[x+1]); break;
                    case 7: p[x] = C8(p[x], p[x+1]); break;
                }
            }

            // Mix columns based on pure randomness! 
            // VOLLBIT
            for(unsigned short n = 0; n < this -> depth*23; n++){
                unsigned short from = rand() % this -> depth;
                unsigned short to = rand() % this -> depth;

                // I have seen this on the internet, I got this!
                // Swap and shit, yeah.
                p[from]^=p[to];
                p[to]^=p[from];
                p[from]^=p[to];

                // Just swapping is not enough, better calculate some more
                p[to] += X1(p[to], p[from]);
                p[from] -= X2(p[from], p[to]);
                p[to] ^= X3(p[to], p[from]);
                p[from] &= X4(p[from], p[to]);
            }
        }
    }

    // Nobody likes blocks with 0es, they look stupid and insecure. Better place some random data
    for(unsigned short x = 0; x < this -> depth*4; x++)
        if(hash.get()[x] == 0)
            hash.get()[x] = rand() & 0xFF;

    // This is a uncrackable hash, even the I can't crack this. Especially the NSA can't!111
    return hash;
}


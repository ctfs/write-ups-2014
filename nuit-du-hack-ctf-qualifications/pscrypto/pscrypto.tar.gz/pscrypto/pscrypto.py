#!/usr/bin/python
""" PSCRYPTO Script """

from itertools import *
from hashlib import sha1


""" Functions declaration """

def ks (s,p):
    while True:
        '''
	KeyStream generator
	'''
	yield s
	s = pow(s*13,p,256)											# Need to multiplicate with a prime number


def xor (*args):
    """
    XOR Function 
    """
    value = 0
    for arg in args:
        value ^= arg
    return value


""" End functions declaration """



def encrypt(key,plain):
    """
    Main function
    """
    ks_generator = []												# Initialize ks_generator
    sha1_pass = sha1(key).digest()										# Key SHA1 generation
    sha1_pass= map(ord, sha1_pass)										# Convert SHA1 into decimal

    for i in range (0, len(sha1_pass),2):
        """
        For loop to generate blocks keystream 
	"""
        s, p = sha1_pass[i:i+2]											# Parsing into 2 octets blocks
	ks_generator.append(ks(s,p))										# Keystream block generation

    pwd = "I love Ponies and Unicorns"										# Password pwd definition for the encryption
    dec_plain = imap(ord,plain)											# Convert each plain characters into ascii decimal
    dec_pwd = imap(ord,pwd)											# Convert each pwd characters into ascii decimal
    ks_generator = izip(*ks_generator)										# izip all keystreams
     
    res = starmap(xor,ks_generator)										# First encryption between all keystreams with XOR function
    pk_crypt = starmap(xor, izip(res,dec_plain,cycle(dec_pwd)))							# XOR encryption between res, plain and pwd
    encrypt_res = imap(chr,pk_crypt)										# Convert the encryption result into char
    encrypt_res = ''.join(encrypt_res)										# Join each encrypt character into sentence
    return encrypt_res



    """
    HELP : http://bit.ly/IqCPuj
    """

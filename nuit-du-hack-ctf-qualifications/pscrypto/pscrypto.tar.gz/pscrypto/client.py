#!/usr/bin/python
""" pscrypt-filer client

ps-crypt file is a multi-user password-protected and encrypted file server.
It does not provide perfect forward secrecy; your files are safe however.
"""

import hashlib
import pscrypto
import argparse

from twisted.internet import protocol, reactor


def xorstr(str1, str2):
    return ''.join([chr(ord(chr1) ^ ord(chr2))
                    for chr1, chr2 in zip(str1, str2)])


class FilerProtocol(protocol.Protocol):
    """ Client filer protocol.
    """

    def __init__(self):
        self.buffer = ""

    def connectionMade(self):
        self.transport.write(chr(self.factory.opcode))
        self.transport.write(self.factory.argument)
    
    def dataReceived(self, data):
        self.buffer += data

    def connectionLost(self, reason):
        self.factory.handle(self.buffer)
        reactor.stop()


class FilerListFactory(protocol.ClientFactory):

    protocol = FilerProtocol
    opcode = 1
    separator = " "

    def __init__(self, user, password):
        self.argument = user

    def handle(self, filelist):
        files = filelist.split(self.separator)
	print "\n".join(files)


class FilerGetFactory(protocol.ClientFactory):

    protocol = FilerProtocol
    opcode = 2

    def __init__(self, user, password, filename):
        self.argument = "%s/%s" % (user, filename)
	#print repr(password)
        self.password = hashlib.sha1(password).digest()

    def handle(self, contents):
        assert len(contents) >= 20
        key = xorstr(contents[:20], self.password)
	#print key.encode("hex")
	print pscrypto.encrypt(key, contents[20:])
	#print final


if __name__ == '__main__':
    parser = argparse.ArgumentParser("ps-crypt filer client, secure file download")
    parser.add_argument("server", help="ip or hostname of the server")
    parser.add_argument("port", type=int, help="port to connect to")
    parser.add_argument("user", help="username")
    parser.add_argument("password", help="password")
    parser.add_argument("operation", choices=['ls', 'get'], help="operation to perform")
    parser.add_argument("filename", nargs='?', default=None)
    args = parser.parse_args()
    # create the right factory
    if args.operation == "ls":
        factory = FilerListFactory(args.user, args.password)
    if args.operation == "get":
        if not args.filename:
            parser.error("you must specify a file to retrieve")
        factory = FilerGetFactory(args.user, args.password, args.filename)
    # connect to the server
    reactor.connectTCP(args.server, args.port, factory)
    reactor.run()

$ ./E 1 69219086192344 flag.png eflag.bin

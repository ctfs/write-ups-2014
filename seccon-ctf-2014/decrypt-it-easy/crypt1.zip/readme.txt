$ ./rnd crypt1.png ecrypt1.bin

import os
from flask import request, send_file, session,g,redirect, url_for,abort,render_template,flash
from sqlite3 import dbapi2 as sqlite3
from werkzeug import secure_filename
from flask_bootstrap import Bootstrap
from wtforms import Form, BooleanField, TextField, PasswordField, validators
from app import app
import random
import base64
import subprocess
from hashlib import sha1
import string
import random

Bootstrap(app)
app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024
UPLOAD_FOLDER = 'C:\\Users\\phduser\\Desktop\\task\\'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
KEY = 'alalaololoYAVODITELNLOsada3424234fsdf!!!!'
FNAMELEN = 17

def crypt(data, key):
    """RC4 algorithm"""
    x = 0
    box = range(256)
    for i in range(256):
        x = (x + box[i] + ord(key[i % len(key)])) % 256
        box[i], box[x] = box[x], box[i]
    x = y = 0
    out = []
    for char in data:
        x = (x + 1) % 256
        y = (y + box[x]) % 256
        box[x], box[y] = box[y], box[x]
        out.append(chr(ord(char) ^ box[(box[x] + box[y]) % 256]))

    return ''.join(out)

def encrypt(data, key):
    """RC4 encryption with random salt and final encoding"""
    data = crypt(data, key)
    return data.encode('hex')

def decrypt(data, key):
    """RC4 decryption of encoded data"""
    
    return crypt(data.decode('hex'), key)

@app.route("/", methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            sfname = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
            try:    
                file.save(sfname)
            except:
                pass
            cmd = ["C:\\Program Files\\ESET\\ESET NOD32 Antivirus\\ecls.exe", '/scan-timeout=10', '/no-subdir'] + (UPLOAD_FOLDER + file.filename).split()
            try:
                subprocess.check_call(cmd, shell=False)
                ret = 0
            except subprocess.CalledProcessError as e:
                ret = e.returncode
            if ret == 0:
                token = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in xrange(FNAMELEN))
                randfname = UPLOAD_FOLDER + token
                print 'renaming %s to %s' % (sfname, randfname)
                os.rename(sfname, randfname)
                link = encrypt(token, KEY)
                return render_template('filepage.html', link=link)
            else:
                os.remove(sfname)
                return render_template('error.html', retcode=ret)
    return render_template('form.html')
 
@app.route('/getfile/<fname>')
def getfile(fname):
    fname = decrypt(fname, KEY)
    resp = send_file(UPLOAD_FOLDER + fname, as_attachment=True)
    return resp

from gevent.wsgi import WSGIServer
from gevent.monkey import patch_all
patch_all()
import socket
socket.setdefaulttimeout(10)
from app import app
import sys

if __name__ == '__main__':
	if len(sys.argv) > 1 and sys.argv[1] == 'debug':
		print 'debug mode'
		app.run(debug=True, port=8080, host='0.0.0.0')
	else:
		http_server = WSGIServer(('', 8080), app)
		http_server.serve_forever()


#!/usr/bin/python
from handler import Handler
import readline

SERVER = '127.0.0.1'
#SERVER = '10.0.2.2'
PORT = 31337
BANNER = """
  __  __  ____   ____      _ _ _   _
 |  \/  |/ __ \ / __ \    | (_) | | |
 | \  / | |  | | |  | | __| |_| |_| |_ ___ _ __
 | |\/| | |  | | |  | |/ _` | | __| __/ _ \ '__|
 | |  | | |__| | |__| | (_| | | |_| ||  __/ |
 |_|  |_|\____/ \____/ \__,_|_|\__|\__\___|_|


"""


class UI(object):
    def __init__(self):
        handler = Handler(SERVER, PORT)
        print BANNER
        print "Welcome to Mooditter! Got moo?"
        print "Print 'help' if you don't know what to moo^Wdo"
        while True:
            data = raw_input(">>> ").split(' ')
            if data[0] in dir(handler):
                try:
                    print getattr(handler, data[0])(*data[1:])
                except Exception as e:
                    print "Something went wrong"
                    print e
            else:
                print "Unknown command", data[0].__repr__()


UI()

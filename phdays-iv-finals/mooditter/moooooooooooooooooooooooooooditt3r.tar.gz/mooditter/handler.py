import struct
import json
import sys
from cowsay import build_bubble, build_cow
from tabulate import tabulate
from socket import socket
from config import TOKEN, BUFF_MAXSIZE
from user import User
import ctypes



class Handler(object):
    def __init__(self, server, port):
        self._user = None
        self._server = server
        self._port = port
	self._buff = None

    def __del__(self):
        print "Good bye!"

    def __api_request__(self, obj):
        obj["token"] = TOKEN
        s = socket()
        s.settimeout(10)
        s.connect((self._server, self._port))
	
        dumped = json.dumps(obj)
        if len(dumped) > BUFF_MAXSIZE:
            raise Exception("Too long request to server")
        s.send(dumped+"\n")
        data = s.recv(4)
        ln = struct.unpack("I", data)[0]
        if ln > BUFF_MAXSIZE:
            raise Exception("Too long response from server ")

	BUF_SIZE = ln
	self._buff  = ctypes.create_string_buffer(ln)
        s.recvfrom_into(self._buff, 10240)
        try:
            res = json.loads(str(self._buff.value))
        except Exception as e:
            raise Exception("Error occured"+str(e))
        if 'error' in res:
            raise Exception(res['error'])
        return res


    def help(self):
        "help - Print help"
        res = []
        for func_name in dir(Handler):
            if not func_name.startswith("__"):
                func = getattr(Handler, func_name)
                res.append(func.__doc__)
        return "\n".join(res)

    def quit(self):
        "quit - Quit"
        sys.exit(0)

    def register(self, name, password):
        "register [name] [password] - Register new user"
        obj = {"cmd": "AddUser", "args": [name, password]}
        res = self.__api_request__(obj)
        if 'ok' in res:
            return res['ok']
        else:
            return res['error']

    def auth(self, name, password):
        "auth [name] [password] - Authenticate"
        obj = {"cmd": "Auth", "args": [name, password]}
        res = self.__api_request__(obj)
        if res['id']:
            self._user = User(res['id'][0])
            return "Authenticated! Hello "+name+"!"
        else:
            return "Invalid username/password"

    def post(self, title, text):
        "post [title] [text] - Post a moodeet"
        if self._user is None:
            return "You must be authenticated to perform this action"
        else:
            obj = {"cmd": "AddMessage", "args": [self._user.id, '0', title, text]}
            return self.__api_request__(obj)

    def reply(self, to, title, text):
        "reply [to] [title] [text] - Reply to another message"
        if self._user is None:
            return "You must be authenticated to perform this action"
        else:
            try:
                toid = int(to, 10)
            except:
                raise Exception("Invalid message id")
            obj = {"cmd": "GetMessages", "args": [self._user.id]}
            list = self.__api_request__(obj)
            if toid not in [x[0] for x in list]:
                raise Exception("No message with such ID")
            obj = {"cmd": "AddMessage", "args": [self._user.id, toid, title, text]}
            return self.__api_request__(obj)

    def list(self):
        "list - list all messages"
        if self._user is None:
            raise Exception("You must be authenticated to perform this action")
        else:
            obj = {"cmd": "GetMessages", "args": [self._user.id]}
            res = self.__api_request__(obj)
            return tabulate(res, headers=["#", "Title"])

    def view(self, message_id):
        "view [msg_id] - View conversation"
        if self._user is None:
            raise Exception("You must be authenticated to perform this action")
        obj = {"cmd": "GetConversation", "args": [self._user.id, message_id]}
        messages = self.__api_request__(obj)
        res = ''
        for msg in messages:
            title = "*"+msg[3]+"*"
            res += build_bubble(title.__format__("40")+msg[4])+"\n"
        res += build_cow()
        return res

    def delete(self, message_id):
        "delete [msg_id] - Delete message"
        if self._user is None:
            raise Exception("You must be authenticated to perform this action")
        obj = {"cmd": "DeleteMessage", "args": [self._user.id, message_id]}
        res = self.__api_request__(obj)
        return res

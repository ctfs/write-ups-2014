class User(object):
	def __init__(self, user_id):
		self.id = user_id

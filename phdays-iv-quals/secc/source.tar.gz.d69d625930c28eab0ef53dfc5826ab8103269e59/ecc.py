#!/usr/bin/env python
#-*- coding:utf-8 -*-

import hashlib
from libnum import invmod

NULL_POINT = (None, None)


def xor(a, b):
    return "".join([chr(ord(a[i]) ^ ord(b[i % len(b)])) for i in xrange(len(a))])


def s2n(s):
    if not len(s):
        return 0
    return int(s.encode("hex"), 16)


class Curve:
    def __init__(self, **kw):
        self.__dict__.update(kw)

    def is_null(self, p):
        return p == NULL_POINT

    def is_neg(self, p1, p2):
        x1, y1 = p1
        x2, y2 = p2
        return (x1 == x2 and y1 == -y2 % self.p)

    def add(self, p1, p2):
        if self.is_null(p1):
            return p2

        if self.is_null(p2):
            return p1

        if self.is_neg(p1, p2):
            return NULL_POINT

        x1, y1 = p1
        x2, y2 = p2

        l = 0
        if x1 != x2:
            l = (y2 - y1) * invmod(x2 - x1, self.p)
        else:
            l = (3 * x1 ** 2 + self.a) * invmod(2 * y1, self.p)

        x = (l * l - x1 - x2) % self.p
        y = (l * (x1 - x) - y1) % self.p  # yes, it's that new x
        return (x, y)

    def power(self, p, n):
        if n == 0 or self.is_null(p):
            return NULL_POINT

        res = NULL_POINT
        while n:
            if n & 1:
                res = self.add(res, p)
            p = self.add(p, p)
            n >>= 1
        return res

    def derive(self, p):
        return hashlib.sha256(str((p[0] << 10) / p[1])).digest()


p256 = Curve(
    a=-3,
    b=0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b,
    p=115792089210356248762697446949407573530086143415290314195533631308867097853951
)

G = (
    0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
    0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5
)

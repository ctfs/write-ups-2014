#!/usr/bin/env python
#-*- coding:utf-8 -*-

import os
import random
import hashlib

from ecc import p256, G, s2n, xor

PASSWORD = s2n(open(os.path.join(os.path.dirname(__file__), "password.txt")).read().strip())
FLAG = open(os.path.join(os.path.dirname(__file__), "flag.txt")).read().strip()


def main():
    print "Auth:"

    auth = raw_input()

    if hashlib.sha1(auth).hexdigest() != "375d5c01ca1b8c3863024d10aac7713472eb5033":  # secch4l*
        print "nope"
        return

    prefix = os.urandom(8)

    print "Proof of work, please"
    print "Prefix is (hexed) ", prefix.encode("hex")

    test = raw_input().decode("hex")

    if not test.startswith(prefix) or len(test) > 16:
        print "nope"
        return

    h = hashlib.sha1(test).hexdigest()

    if not h.startswith("000000"):
        print "nope"
        return

    goflag()


def goflag():
    print "EC PASSWORD CHECK"

    r = random.randint(31337, 1 << 250)
    R = p256.power(G, r)

    print "R =", R

    print "SHARED SECRET = R ^ PASSWORD"

    S = p256.power(R, PASSWORD)

    key = p256.derive(S)

    cipher = encrypt(FLAG, key)
    print "ENCRYPTED MESSAGE:", cipher.encode("hex")


def encrypt(msg, key):
    iv = os.urandom(8)
    stream = hashlib.sha256(iv + key).digest()
    stream = hashlib.sha256(stream + iv + key).digest()
    cipher = iv + xor(msg, stream)
    return cipher


if __name__ == '__main__':
    main()

<?php
error_reporting(0);
include 'phplatex.php';

function getmicrotime() 
{ 
    list($usec, $sec) = explode(" ", microtime()); 
    return ((float)$usec + (float)$sec); 
} 

function generate() {
	$a = mt_rand(0, 15);
	$b = mt_rand($a+1, 30);
	$p = mt_rand(1,7);
	$c = array();
	$sol = 0.0;
	for ($i=$p; $i >= 0; --$i) {
		$k = 0;
		while ($k === 0)
			$k = mt_rand(-99, 99);
		$c[$i] = $k;
		$sol += ($k * (pow($b, $i+1) - pow($a, $i+1))) / ($i+1);
	}
	$f = '';
	$_SESSION['ans'] = $sol;
	foreach($c as $x => $y) {
		if ($x == $p) {
			$f .= $y;
		} else {
			$f .= ($y >= 0) ? "+{$y}" : $y;
		}
		$f .= "x^{$x}";
	}
	$f = "$$\int\limits_{".$a."}^{".$b."} ".$f."\,dx$$";
	print texify($f, 200);
	$_SESSION['time'] = getmicrotime();
}

session_start();
$TIME = (float)4.0;
$ROUND_CNT = 25;
$EPS = 1.0;

if (isset($_POST['submit'], $_POST['ans'])) {
	if (!isset($_SESSION['ans']) || empty($_SESSION['ans'])) {
		echo '<h1>Wrong answer!</h1>';
		$_SESSION['level'] = 0;
		header('Refresh: 1; URL=index.php');
		exit();
	} else if (getmicrotime() - $_SESSION['time'] < $TIME) {
		if (abs((float)$_POST['ans'] - $_SESSION['ans']) < $EPS) {
			$_SESSION['level'] += 1;
			if ($_SESSION['level'] === $ROUND_CNT) {
				echo "Okay. CTF{b221bd68a85f9e542eb545a9f7703b28}";
				exit();
			}
		} else {
			echo '<h1>Wrong answer!</h1>';
			$_SESSION['level'] = 0;
			header('Refresh: 1; URL=index.php');
			exit();
		} 
	} else {
		echo '<h1>So slow...</h1>';
		$_SESSION['level'] = 0;
		header('Refresh: 2; URL=index.php');
		exit();
	}
} else {
	$_SESSION['level'] = 0;
}
$num = $_SESSION['level'];
?>
<html>
<title>Integral Captcha Challenge</title>
<body>
	<h1>Round <?=($num+1)."/".$ROUND_CNT;?></h1>
	<p>Solve this:</p>
	<p><?=generate();?></p>
	<form action="" method="POST">
		<input type="text" name="ans" maxlength="30">
		<input type="submit" name="submit" value="go">
	</form>
	
</body>
</html>


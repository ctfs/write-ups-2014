#!/bin/sh
iptables -t nat -A PREROUTING -p tcp --dport 0 -j DNAT --to-destination :8000

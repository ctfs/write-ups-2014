#!/usr/bin/python
import sys
import struct
import zlib
import socket

class Client:
	def __init__(self, ip):
		#init
		self.ip = ip
		self.port = 0x1337
		#connect
		self.conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.conn.connect((self.ip, self.port))
		#recieve e
		self.e = self.Recv()
		#recieve n
		self.n = self.Recv()
		self.e, self.n = int(self.e), int(self.n)

	def Recv(self):
		#unpack data
		length = struct.unpack('!H', self.conn.recv(2))
		data = zlib.decompress(self.conn.recv(length[0]))
		return data

	def Pack(self, data):
		#compress data
		data = zlib.compress('%s' % data)
		length = struct.pack('!H', len(data))
		return '%s%s' % (length, data)

	def Send(self, msg):
		#send message
		msg = int(msg.encode('hex'),16)
		assert(msg < self.n)
		msg = pow(msg, self.e, self.n)
		self.conn.send(self.Pack(msg))
		print '[+] Message send'

	def __del__(self):
		#close connection
		self.conn.close()

if len(sys.argv) != 2:
	print 'Usage: %s <ip>' % sys.argv[0]
	sys.exit(0)

flag = open('message.txt').readline()
test = Client(sys.argv[1])
test.Send(flag)

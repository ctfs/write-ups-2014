<?php
$config = array();
$config['root'] = '/var/www/';
$config['key'] = '';
$config['IP'] = array('127.0.0.1');
$config['password'] = '';
?>

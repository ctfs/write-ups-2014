<?php
include 'config.php';
include 'classes.php';

if (!in_array($_SERVER['REMOTE_ADDR'], $config['IP']))
	die('<h1>Access denied</h1>');

$handler = new Session();
session_start();

if (isset($_SESSION['auth'])) {
	echo '<p>Welcome, admin!</p>';
	$files = scandir($config['root'].'/images');
	$cnt = count($files);
	echo '<p>Total images uploaded: '.$cnt.'</p>';
	exit();
}

if (isset($_POST['password'])) {
	if (md5($_POST['password']) === $config['password']) {
		$_SESSION['auth'] = 1;
		header('Location: admin.php');
	} else {
		echo '<h1>Access denied</h1>';
	}
	exit();
}
?>
<html>
<body>
	<b>Enter password:</b>
	<form action="admin.php" method="POST">
		<input type="text" name="password">
		<input type="submit" name="submit" value="GO">
	</form>
</body>
</html>

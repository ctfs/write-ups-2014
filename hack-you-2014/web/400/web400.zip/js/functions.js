function Send(data) {
	data = data.split(",")
	data = encodeURIComponent(data[1]);
	var req = new XMLHttpRequest();
	var status = document.getElementById("status")
	req.open("POST", "index.php", false);
	req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	req.send("action=Upload&param=" + data);
	status.innerHTML = req.responseText;
}

function Upload() {
	var file = document.getElementById("image");
	var status = document.getElementById("status")
	var f = file.files[0];
	if (f) {
		var r = new FileReader();
		r.onload = function(e) { Send(e.target.result) }
        r.readAsDataURL(f);
	} else {
		status.innerHTML = "Error";
	}
}

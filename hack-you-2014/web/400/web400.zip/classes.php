<?php
class View {
	function __construct($page) {
		ob_start();
		readfile('html/header.html');
		switch ($page) {
			case 'index':
				readfile('html/index.tpl.html');
				break;
			case 'upload':
				readfile('html/upload.tpl.html');
				break;
		}
		readfile('html/footer.html');
	}
	function __toString() {
		$this->content = ob_get_contents();
		ob_end_clean();
		return $this->content;
	}
}

class Upload {
	function __construct($data) {
		global $config;
		$this->data = base64_decode($data);
		$this->filename = md5(uniqid(rand(), true));
		$this->path = $config['root'].'images/'.$this->filename;
		file_put_contents($this->path, $this->data);
		$this->type = exif_imagetype($this->path);
	}
	function __toString() {
		if ($this->type) {
			$link = 'http://'.$_SERVER['SERVER_NAME'].'/'.$this->filename;
			return '<p>Successfully updated!</p>Your link: <a href="'.$link.'">'.$link.'</a>';
		} else {
			return '<p>Wrong file type!<p>';
		}
	}
	function __destruct() {
		if ($this->type) {
			echo '<p>Some file info:<pre>';
			passthru('exiv2 '.$this->path);
			echo '</pre></p>';
		} else {
			unlink($this->path);
		}
	}
}

class Image {
	function __construct($filename) {
		global $config;
		$this->filename = $filename;
		$this->path = $config['root'].'images/'.$this->filename;
	}
	function __toString() {
		if (preg_match('/^[a-f0-9]{32}$/', $this->filename) && file_exists($this->path)) {
			$this->type = exif_imagetype($this->path);
			$this->mime = image_type_to_mime_type($this->type);
			header('Content-Type: '.$this->mime);
			return file_get_contents($this->path);
		} else {
			return '<h1>Error</h1>';
		}
	}
}

class Session {
    function __construct() {
    	global $config;
        session_set_save_handler(
            array($this, "open"), array($this, "close"),  array($this, "read"),
            array($this, "write"),array($this, "destroy"),array($this, "gc")
        );
        $this->key = $config['key'];
        $this->size = 32;
        $this->path = '/tmp';
    }

    function encrypt($data) {
        $iv = mcrypt_create_iv($this->size, MCRYPT_RAND);
        $key = hash('sha256', $this->key, true);
        $data = $iv.mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $data, MCRYPT_MODE_CBC, $iv);
        return $data;
    }

    function decrypt($data) {
        $key = hash('sha256', $this->key, true);
        $iv = substr($data, 0, $this->size);
        $data = substr($data, $this->size);
        $data = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, $data, MCRYPT_MODE_CBC, $iv);
        return $data;
    }

    function write($id, $data) {
        $path = $this->path.'/'.$id;
        $data = $this->encrypt($data);
        file_put_contents($path, $data);
    }

    function read($id) {
        $path = $this->path.'/'.$id;
        $data = null;
        if (is_file($path)) {
            $data = file_get_contents($path);
            $data = $this->decrypt($data);
        }
        return $data;
    }

    function open($sess_path, $sess_id) {
    	//nothing
    }

    function close() {
        return true;
    }

    function gc($maxlifetime) {
        $path = $this->path.'/*';
        foreach (glob($path) as $file) {
            if (filemtime($file) + $maxlifetime < time() && file_exists($file)) {
                unlink($file);
            }
        }
        return true;
    }

    function destroy($id) {
        $path = $this->path.'/'.$id;
        if (is_file($path)) {
            unlink($path);
        }
        return true;
    }
}
?>

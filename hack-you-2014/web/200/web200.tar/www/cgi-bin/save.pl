#!/usr/bin/perl
use CGI;
use DBI;
use Digest::MD5;

sub MD5 {
	$h = Digest::MD5->new;
	$h->add($_[0]);
	return $h->hexdigest;
}

sub Main {
  $req = new CGI;
  $ip = $req->remote_host();
  if ($req->http('HTTP_X_FORWARDED_FOR')) {
    $ip = $req->http('HTTP_X_FORWARDED_FOR');
  }
  print $req->header();
  print $req->start_html('Save score');
  $hash = $req->param('hash');
  $score = int($req->param('playerScore'));
  $nick = $req->param('playerName');
  $key = "pc8XW2xUJcWMFVGkZ5PL";
  if ($nick ne '' & MD5($score.$nick.$key) eq $hash) {
  	$ok = 1;
  	open(FILE, ">>", "./data/".MD5($nick)."/".$ip) || ($ok = 0);
  	if ($ok) {
  		$time = scalar localtime();
	  	print FILE "<tr><td>".$time."</td><td>".$score."</td><tr>\n";
	  	close(FILE);
  	}
  }
  print $req->end_html();
}

Main();

#!/usr/bin/perl
use CGI;
use CGI::Session;
use DBI;
use Digest::MD5;

sub MD5 {
	$h = Digest::MD5->new;
	$h->add($_[0]);
	return $h->hexdigest;
}

sub Main {
	$title = "Personal Area";
	$req = new CGI;
	$db = DBI->connect("dbi:mysql:snake", "daniel", "E9nENHbtkG");
	if ($req->param('submit')) {
		$login = $req->param('login');
		$password = MD5($req->param('password'));
		$sth = $db->prepare("SELECT * FROM users WHERE login = ? AND password = ?");
		$sth->execute($login, $password);
		if ($sth->fetchrow_array()) {
			$session = new CGI::Session();
			$session->param('login', $login);
			print $session->header(-location=>'index.pl');
		} else {
			print $req->header();
			print $req->start_html($title);
			print $req->h1('Wrong login/password!');
			print $req->end_html();
		}
		exit;
	}

	$session = CGI::Session->load();
	if ($req->param('act') eq 'logout') {
		$session->delete();
	      	print $session->header(-location=>'index.pl');
      		exit;
	} 

	print $req->header();
	print $req->start_html($title);
	if ($session->is_empty) {
		print $req->b('Auth please');
		print $req->startform;
		print $req->textfield(-name=>'login');
		print $req->br;
		print $req->textfield(-name=>'password');
		print $req->br;
		print $req->submit(-name=>'submit', -value=>'OK', -action=>"index.pl", -method=>"POST");
		print $req->endform;
		print $req->a({href => 'register.pl'}, "Register");
	} else {
		$login = $session->param('login');
		print $req->p('Hello, '.$login.'!');
		if ($req->param('ip')) {
			$file = './data/'.MD5($login)."/".$req->param('ip');
			if (-e $file) {
				open FILE, $file;
				$html = '';
				while (<FILE>) {
					$html .= $_;
				}
				close(FILE);
				print $req->start_table({border=>1});	
				print $req->Tr($req->th(['Date', 'Score']));
				print $html;
				print $req->end_table();	
				print $req->a({href=>'index.pl'}, 'Back');			
			} else {
				print $req->h1('Error');
			}
		} else {
			print $req->p('Here you can view information about your games from any IP');
			opendir DIR, './data/'.MD5($login);
			print $req->start_table({border=>1});
			while ($file = readdir(DIR)) {
				if ($file =~ m/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/) {
					print $req->Tr($req->td([$req->a({href => "index.pl?ip=".$file}, $file)]));
				}
			}
			print $req->end_table();
			print $req->br;
			print $req->a({href=>'index.pl?act=logout'}, 'Logout');
		}
	}
	print $req->end_html();
}

Main();

#!/usr/bin/perl
use CGI;
$req = new CGI;
print $req->header();
print $req->start_html();
print $req->p(`id`);
print $req->end_html();


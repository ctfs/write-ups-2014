#!/usr/bin/perl
use CGI;
use DBI;
use Digest::MD5;

sub MD5 {
	$h = Digest::MD5->new;
	$h->add($_[0]);
	return $h->hexdigest;
}

sub Main {
	$title = "Personal Area";
	$req = new CGI;
	$db = DBI->connect("dbi:mysql:snake", "daniel", "E9nENHbtkG");
	print $req->header();
	print $req->start_html($title);
	if ($req->param('submit')) {
		$login = $req->param('login');
		$password = MD5($req->param('password'));
		if ($login ne '' & $password ne '') {
			$sth = $db->prepare("SELECT * FROM users WHERE login = ?");
			$sth->execute($login);
			if ($sth->fetchrow_array()) {
				print $req->h1('Username already exists!');
			} else {
				$sth = $db->prepare("INSERT INTO users VALUES (?, ?)");
				$sth->execute($login, $password);
				mkdir './data/'.MD5($login);
				print $req->h1('Registered successfully!');
			}
		} else {
			print $req->h1('Error');
		}
	} else {
		print $req->b('Register');
		print $req->startform;
		print $req->textfield(-name=>'login');
		print $req->br;
		print $req->textfield(-name=>'password');
		print $req->br;
		print $req->hidden(-name=>'act', -value=>'register');
		print $req->submit(-name=>'submit', -value=>'ok', -action=>"index.pl", -method=>"POST");
		print $req->endform;
		print $req->br;
		print $req->a({href => 'index.pl'}, "Back");
	}
	print $req->end_html();
}

Main();

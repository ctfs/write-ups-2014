import utils
import subprocess
import sys

subprocess.Popen([sys.executable, 'shellcode.py']).communicate()
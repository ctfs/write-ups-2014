//
//  LFSR.h
//  encrypt_image
//
//  Created by Alexander Verichev on 3/18/14.
//  Copyright (c) 2014 Alexander Verichev. All rights reserved.
//

#ifndef __encrypt_image__LFSR__
#define __encrypt_image__LFSR__

#include <vector>


class LFSR
{
    uint64_t state;
    size_t N;
    
    std::vector<int> taps_sequence;
    
public:
    LFSR();
    LFSR(uint64_t key, size_t _N, std::vector<int>& taps);
    uint8_t operator()();
};


#endif /* defined(__encrypt_image__LFSR__) */

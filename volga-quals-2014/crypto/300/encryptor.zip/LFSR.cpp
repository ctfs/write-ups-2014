//
//  LFSR.cpp
//  encrypt_image
//
//  Created by Alexander Verichev on 3/18/14.
//  Copyright (c) 2014 Alexander Verichev. All rights reserved.
//

#include "LFSR.h"
#include <assert.h>


LFSR::LFSR(uint64_t key, size_t _N, std::vector<int>& taps)
{
    N = _N;
    taps_sequence = taps;
    uint64_t mask = ((uint64_t)1 << N) - 1;
    state = key & mask;
}

uint8_t LFSR::operator()()
{
    assert(state != 0);
    
    uint8_t ret_bit = state & 1;
    uint8_t new_bit = 0;
    
    for (int i = 0; i < taps_sequence.size(); i++)
    {
        uint8_t b = (state >> taps_sequence[i]);
        new_bit ^= b & 1;
    }
    state = (state >> 1) | ((uint64_t)new_bit << N-1);
    
    
    return ret_bit;
}




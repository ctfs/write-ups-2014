//
//  main.cpp
//  encrypt_image
//
//  Created by Alexander Verichev on 3/18/14.
//  Copyright (c) 2014 Alexander Verichev. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "LFSR.h"



uint8_t encryptor(LFSR& X, LFSR& Y, LFSR& Z);
uint8_t* get_keystream(uint64_t key[3], size_t length);
std::string show_usage();


int main(int argc, const char * argv[])
{
    //precess input parameters
    if (argc != 5)
    {
        show_usage();
        return 0;
    }
    if (std::string(argv[1]) != "encrypt" &&
        std::string(argv[1]) != "decrypt")
    {
        show_usage();
        return 0;
    }
    if (std::strlen(argv[2]) < 8)
    {
        show_usage();
        return 0;
    }
    
    
    //retrieve the key
    uint64_t key[3];
    std::stringstream ss;
    ss  << std::hex << std::string(argv[2], 0, 6) << " "
        << std::hex << std::string(argv[2], 6, 2) << " "
        << std::hex << std::string(argv[2], 8, -1);
    ss >> key[0] >> key[1] >> key[2];
    
    
    
    
    //open files and read data
    std::ifstream fin(argv[3], std::ios::binary);
    if (!fin)
    {
        std::cerr << "Failed to open file " << argv[3] << std::endl;
        return -1;
    }
    std::ofstream fout(argv[4], std::ios::binary);
    if (!fout)
    {
        std::cerr << "Failed to open file " << argv[4] << std::endl;
        return -2;
    }
    
    fin.seekg(0, std::ios::end);
    size_t length = fin.tellg();
    fin.seekg(0, std::ios::beg);
    uint8_t* data = new uint8_t[length]{0};
    fin.read((char*)data, length);
    
    
    //encrypt data
    uint8_t* keystream = get_keystream(key, length);
    for (size_t i = 0; i < length; i++)
        data[i] ^= keystream[i];
    
    
    //write data
    fout.write((char*)data, length);
    
    
    
    fin.close();
    fout.close();
    delete [] data;
    delete [] keystream;
    return 0;
}


uint8_t* get_keystream(uint64_t key[3], size_t length)
{
    //x^24+x^7+x^2+x+1
    std::vector<int> X_taps = {0, 17, 22, 23};
    size_t X_size = 24;
    //x^8+x^4+x^3+x^2+1
    std::vector<int> Y_taps = {0, 4, 5, 6};
    size_t Y_size = 8;
    //x^18+x^7+1
    std::vector<int> Z_taps = {0, 11,};
    size_t Z_size = 18;
    
    LFSR X(key[0], X_size, X_taps);
    LFSR Y(key[1], Y_size, Y_taps);
    LFSR Z(key[2], Z_size, Z_taps);
    
    uint8_t* keystream = new uint8_t[length]{0};
    
    
    for (int i = 0; i < length; i++)
        for (int j = 0; j < 8; j++)
            keystream[i] |= encryptor(X, Y, Z) << (7-j);
    
    
    return keystream;
}
uint8_t encryptor(LFSR& X, LFSR& Y, LFSR& Z)
{
    uint8_t x = X();
    uint8_t y = Y();
    uint8_t z = Z();
    
    return x&y ^ y&z ^ z;
}


std::string show_usage()
{
    return "usage: encrypt|decrypt <hex_encoded_key> <path_to_input_file> <path_to_output_file>";
}


<html>
  <head>
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />
    <script src="javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <center><h1><?php echo $title; ?></h1></center>
        <p>
          <?php echo $blurb; echo "\n"; ?>
        </p>
      </div>

#!/usr/bin/env python

from sys import *
import random

if len(argv) < 2:
    print "Usage: python encrypter.py <string_to_encrypt>"
    exit(0)

try:
    _______ = int(open("a.key","r").read().strip())
    ________ = int(open("b.key","r").read().strip())
    _________ = int(open("c.key","r").read().strip())
    __________ = int(open("d.key","r").read().strip())
except:
    print "Failed to read keys!"
    exit(0)

def ____________(_, __):
    while __: _, __ = __, _%__
    return _

def _____________(_, __, ___):
    ____ = 1
    while 1:
        if __ % 2 == 1:
            ____ = ____ * _ % ___
        __ /= 2
        if __ == 0: break
        _ = _ * _ % ___
    return ____

_, __ = argv[1], 0
for ___ in _: __ = (__*256) + ord(___)

___________ = _____________(_________, _______, ________)

random.seed(__________)
while True:
    ____ = random.randint(1, 2**512)
    if ____________(____, ________-1) == 1: break

_____ = _____________(_________, ____, ________)
______ = (__ * _____________(___________, ____, ________)) % ________

print ("[*] Plain text: {0}".format(__))
print ("[*] Encrypted message:")
print ("[*] P : {0}".format(_____))
print ("[*] Q : {0}".format(______))

#!/usr/bin/env python2

import sarge
import msgpack
import struct

sge = sarge.Sarge(file("/home/user/flag").read().strip())

def objecthook(code, data):
    if code == 42:
        return sarge.Sargecmd(data)
    return msgpack.ExtType(code, data)

data = msgpack.unpackb(raw_input(), ext_hook = objecthook)
if sge.authenticate(data["authentication"]):
    data["execute"].run()
else:
    print "Nope"


#!/bin/sh
lighttpd -f web/lighttpd.conf -D

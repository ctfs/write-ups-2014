#include <cairo.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

cairo_t *cr;

static char encoding_table[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                                'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
                                'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
                                'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
                                'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
                                'w', 'x', 'y', 'z', '0', '1', '2', '3',
                                '4', '5', '6', '7', '8', '9', '+', '/'};
static int mod_table[] = {0, 2, 1};


char *base64_encode(const unsigned char *data,
                    size_t input_length,
                    size_t *output_length) {

    *output_length = 1 + (4 * ((input_length + 2) / 3));

    char *encoded_data = calloc(1,*output_length);
    if (encoded_data == NULL) return NULL;

    for (int i = 0, j = 0; i < input_length;) {

        uint32_t octet_a = i < input_length ? (unsigned char)data[i++] : 0;
        uint32_t octet_b = i < input_length ? (unsigned char)data[i++] : 0;
        uint32_t octet_c = i < input_length ? (unsigned char)data[i++] : 0;

        uint32_t triple = (octet_a << 0x10) + (octet_b << 0x08) + octet_c;

        encoded_data[j++] = encoding_table[(triple >> 3 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 2 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 1 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 0 * 6) & 0x3F];
    }

    for (int i = 0; i < mod_table[input_length % 3]; i++)
        encoded_data[*output_length - 2 - i] = '=';

    return encoded_data;
}

/*
cairo_fill (cairo_t *cr);
cairo_move_to (cairo_t *cr, double x, double y);
cairo_rel_move_to (cairo_t *cr, double dx, double dy);
cairo_line_to (cairo_t *cr, double x, double y);
cairo_rel_line_to (cairo_t *cr, double dx, double dy);

cairo_rectangle (cairo_t *cr, double x, double y, double width, double height);

cairo_arc (cairo_t *cr, double xc, double yc, double radius, double angle1, double angle2);
cairo_arc_negative (cairo_t *cr, double xc, double yc, double radius, double angle1, double angle2);

cairo_curve_to (cairo_t *cr, double x1, double y1, double x2, double y2, double x3, double y3);
cairo_rel_curve_to (cairo_t *cr, double dx1, double dy1, double dx2, double dy2, double dx3, double dy3);
*/


float *read_args(unsigned int n) {
    float buf[6] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    const char *a;
    for(float *f = buf; a = strtok(NULL, " \t\r\n"); f++)
        *f = atof(a);
    float *tmp = malloc(n * sizeof(*tmp));
    memcpy(tmp, buf, n * sizeof(*tmp));
    return tmp;
}

void handle_set_source_rgb(void) {
    float *args = read_args(3);
    cairo_set_source_rgb(cr, args[0], args[1], args[2]);
    free(args);
}

void handle_set_line_width(void) {
    float *args = read_args(1);
    cairo_set_line_width(cr, args[0]);
    free(args);
}


void handle_fill(void) {
    float *args = read_args(0);
    cairo_fill(cr);
    free(args);
}

void handle_stroke(void) {
    float *args = read_args(0);
    cairo_stroke(cr);
    free(args);
}

void handle_move_to(void) {
    float *args = read_args(2);
    cairo_move_to(cr, args[0], args[1]);
    free(args);
}

void handle_rel_move_to(void) {
    float *args = read_args(2);
    cairo_rel_move_to(cr, args[0], args[1]);
    free(args);
}

void handle_line_to(void) {
    float *args = read_args(2);
    cairo_line_to(cr, args[0], args[1]);
    free(args);
}

void handle_rel_line_to(void) {
    float *args = read_args(2);
    cairo_rel_line_to(cr, args[0], args[1]);
    free(args);
}

void handle_rectangle(void) {
    float *args = read_args(4);
    cairo_rectangle(cr, args[0], args[1], args[2], args[3]);
    free(args);
}

void handle_arc(void) {
    float *args = read_args(5);
    cairo_arc(cr, args[0], args[1], args[2], args[3], args[4]);
    free(args);
}

void handle_arc_negative(void) {
    float *args = read_args(5);
    cairo_arc_negative(cr, args[0], args[1], args[2], args[3], args[4]);
    free(args);
}

void handle_curve_to(void) {
    float *args = read_args(6);
    cairo_curve_to(cr, args[0], args[1], args[2], args[3], args[4], args[5]);
    free(args);
}

void handle_rel_curve_to(void) {
    float *args = read_args(6);
    cairo_rel_curve_to(cr, args[0], args[1], args[2], args[3], args[4], args[5]);
    free(args);
}

typedef void (*handle_t)(void);
struct cmd_t {
    const char *name;
    handle_t handle;
} cmds[] = {
    {"fill", handle_fill},
    {"stroke", handle_stroke},
    {"move_to", handle_move_to},
    {"rel_move_to", handle_rel_move_to},
    {"line_to", handle_line_to},
    {"rel_line_to", handle_rel_line_to},
    {"curve_to", handle_curve_to},
    {"rel_curve_to", handle_rel_curve_to},
    {"rectangle", handle_rectangle},
    {"arc", handle_arc},
    {"arc_negative", handle_arc_negative},
    {"set_source_rgb", handle_set_source_rgb},
    {"set_line_width", handle_set_line_width},
    {NULL, NULL}
};


struct buffer {
    size_t length;
    char *buf;
};

cairo_status_t write_func(void *closure, const unsigned char *data, unsigned int length) {
    struct buffer *buf = closure;
    buf->buf = realloc(buf->buf, buf->length + length);
    memcpy(buf->buf + buf->length, data, length);
    buf->length += length;
    return CAIRO_STATUS_SUCCESS;
}

int main(void) {
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 400, 400);
    cr = cairo_create (surface);
    while(true) {
        char *buf = NULL;
        if(getline(&buf, &(size_t){0}, stdin) < 0)
            break;
        const char *given_cmd = strtok(buf, " \t\r\n");
        if(!given_cmd)
            continue;
        for(const struct cmd_t *cmd = cmds;; ++cmd) {
            if(!cmd->name)
                return 1;
            if(strcasecmp(cmd->name, given_cmd))
                continue;
            cmd->handle();
            break;
        }
        free(buf);
    }
    cairo_destroy(cr);
    {
        struct buffer plain_png;
        plain_png.length = 0;
        plain_png.buf = NULL;
        cairo_surface_write_to_png_stream(surface, write_func, &plain_png);

        struct buffer base64_png;
        base64_png.buf = base64_encode(plain_png.buf, plain_png.length, &base64_png.length);

        printf(base64_png.buf);

        free(plain_png.buf);
        free(base64_png.buf);
    }
    cairo_surface_destroy(surface);
}

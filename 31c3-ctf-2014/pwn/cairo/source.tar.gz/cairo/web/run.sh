#!/bin/sh
lighttpd -f lighttpd.conf -D

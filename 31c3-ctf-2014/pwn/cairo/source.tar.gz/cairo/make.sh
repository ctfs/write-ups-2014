#!/bin/sh

gcc -std=gnu99 -o cairo -s -O3 cairo.c $(pkg-config --cflags --libs cairo)

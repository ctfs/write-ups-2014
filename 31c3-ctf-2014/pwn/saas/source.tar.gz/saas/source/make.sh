#!/bin/sh
g++ -fstack-protector-all -Wl,-z,relro,-z,now -pie -O2 -m32 -o challenge challenge.cpp -I/usr/include/lua5.2 -I/usr/include/x86_64-linux-gnu/ /usr/lib/i386-linux-gnu/liblua5.2.so.0 -std=c++11

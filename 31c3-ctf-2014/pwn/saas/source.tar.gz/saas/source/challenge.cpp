#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <algorithm>

#include <lua5.2/lua.hpp>

const char little_endian_lower_than[] = R"XXX(
function f(l, r)
    return l < r
end
)XXX";
const char little_endian_greater_than[] = R"XXX(
function f(l, r)
    return l > r
end
)XXX";
const char big_endian_lower_than[] = R"XXX(
function bs(x)
    local r = 0
    for i = 0, 3 do
        local y = x % 256
        r = (r * 256) + y
        x = (x - y) / 256
    end
    return r
end

function f(l, r)
    return bs(l) > bs(r)
end
)XXX";
const char big_endian_greater_than[] = R"XXX(
function bs(x)
    local r = 0
    for i = 0, 3 do
        local y = x % 256
        r = (r * 256) + y
        x = (x - y) / 256
    end
    return r
end

function f(l, r)
    return bs(l) < bs(r)
end
)XXX";
const char popcount_lower_than[] = R"XXX(
function pc(x)
    local counter = 0
    while (x > 0) do
        local y = x % 2
        counter = counter + y
        x = (x - y ) / 2
    end
    return counter
end

function f(l, r)
    return pc(l) < pc(r)
end
)XXX";
const char popcount_greater_than[] = R"XXX(
function pc(x)
    local counter = 0
    while (x > 0) do
        local y = x % 2
        counter = counter + y
        x = (x - y ) / 2
    end
    return counter
end

function f(l, r)
    return pc(l) > pc(r)
end
)XXX";

struct Algo {
    const char *name;
    const char *code;
};
static const Algo algos[] = {
    {"little endian, lower than", little_endian_lower_than},
    {"little endian, greater than", little_endian_greater_than},
    {"big endian, lower than", big_endian_lower_than},
    {"big endian, greater than", big_endian_greater_than},
    {"popcount, lower than", popcount_lower_than},
    {"popcount, greater than", popcount_greater_than},
    {"custom", NULL},
};
static const std::size_t algos_count = sizeof(algos) / sizeof(*algos);
std::vector<char> custom_code;
lua_State *L = NULL;

bool comparator(uint32_t l, uint32_t r) {
    if(l == 0xdeadbeef || r == 0xdeadbeef)
        exit(1);
    bool res;
    if(!L)
        return false;
    lua_getglobal(L, "f");
    if(!lua_isfunction(L, -1))
        goto ERR;
    lua_pushnumber(L, l);
    lua_pushnumber(L, r);
    if(lua_pcall(L, 2, 1, 0) != LUA_OK)
        goto ERR;
    res = lua_toboolean(L, -1);
    lua_pop(L, 1);
    return res;

    ERR:
    lua_close(L);
    L = NULL;
    return false;
}

int lua_print(lua_State* L) {
  int n = lua_gettop(L);  /* number of arguments */
  int i;
  for (i=1; i<=n; i++) {
    const char *s = lua_tostring(L, i);  /* get result */
    if(s != NULL)
        printf("'%s'\n", s);
    else
        printf("(NULL)\n");
  }
  return 0;
}

int main(int argc, char **argv) {
    uint32_t numbers[1024+1];
    uint32_t algo_id, count, newline_counter;
    const char *code;
    numbers[0] = 0xdeadbeef;

    std::cout << "Welcome to SaaS (Sorting as a Service)!" << std::endl << std::endl;
    while(true) {
        std::cout << "Please choose your sorting algorithm:" << std::endl;
        std::cout << "0) exit" << std::endl;
        for(uint32_t a(0); a < algos_count; ++a)
            std::cout << (a + 1) << ") " << algos[a].name << std::endl;
        while(true) {
            (std::cout << ": ").flush();
            if(!(std::cin >> algo_id).good())
                return 0;
            if(algo_id <= algos_count)
                break;
            std::cout << "Invalid algo" << std::endl;
        }
        if(!algo_id--) {
            std::cout << "Goodbye" << std::endl;
            return 0;
        }
        if(!algos[algo_id].code) {
            //user chose custom, read the code from stdin
            std::cout << "Please insert your lua code, end with 3 empty lines:" << std::endl;
            newline_counter = 0;
            custom_code.clear();
            while(true) {
                char tmp;
                if(!std::cin.get(tmp).good())
                    return 0;
                if(!tmp)
                    break;
                if((tmp == '\n') && (newline_counter++ >= 3))
                    break;
                if((tmp != '\n') && (tmp != '\r'))
                    newline_counter = 0;
                custom_code.push_back(tmp);
            }
            custom_code.push_back(0);
            code = &custom_code[0];
        }
        else
            code = algos[algo_id].code;

        //compile lua code
        alarm(10);
        if(!(L = luaL_newstate()))
            return 1;
        lua_pushcfunction(L, lua_print);
        lua_setglobal(L, "print");
        lua_pop(L, 1);
        if(luaL_loadbufferx(L, code, strlen(code), "code", "t") != LUA_OK)
            goto ERR;
        if(lua_pcall(L, 0, 0, 0) != LUA_OK)
            goto ERR;
        lua_getglobal(L, "f");
        if(!lua_isfunction(L, -1))
            goto ERR;
        lua_pop(L, 1);
        alarm(0);
        //lua code compiled and sanity check successfull

        std::cout << "How many numbers do you want to sort(max 1024)?" << std::endl;
        while(true) {
            (std::cout << ": ").flush();
            if(!(std::cin >> count).good())
                return 0;
            if(count <= 1024)
                break;
            std::cout << "Invalid count" << std::endl;
        }
        for(uint32_t n(0); n < count; n++) {
            (std::cout << "Number " << (n + 1) << ": ").flush();
            if(!(std::cin >> numbers[n+1]).good())
                return 0;
        }

        //sort the numbers
        alarm(10);
        std::sort(numbers + 1, numbers + 1 + count, comparator);
        alarm(0);

        //print the now sorted numbers
        for(uint32_t n(0); n < count; n++)
            std::cout << "Number " << (n + 1) << " is now: " << numbers[n+1] << std::endl;

        goto FINE;

        ERR:
        std::cout << "Error while parsing your code" << std::endl;

        FINE:
        if(L)
            lua_close(L);
        L = NULL;
    }
}

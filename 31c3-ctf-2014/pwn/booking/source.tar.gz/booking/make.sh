#!/bin/sh
mkdir chroot
gcc booking.c -Wl,-z,relro,-z,now -O3 -s -pie -fPIE -std=gnu99 -fstack-protector-all -ochroot/service -lmysqlclient || exit
cp /lib/x86_64-linux-gnu/libgcc_s.so.1 /lib64/ld-linux-x86-64.so.2 `ldd chroot/service | egrep ' => /' | egrep -o '=> [^ ]+ ' | cut -c4-` chroot/
for p in usr lib bin lib64; do
	ln -s . chroot/$p 2> /dev/null
done

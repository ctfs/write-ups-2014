#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <inttypes.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <mysql/mysql.h>

MYSQL *con;

#define DAYS_TO_SECONDS (24 * 60 * 60)

//constants used for the occupancy blob evaluation
static const uint8_t OFFSETS_A[] = {19, 64, 100, 128, 149, 164, 174, 180, 183, 184};
static const uint8_t OFFSETS_CI[] = {0, 1, 3, 6, 10, 15, 21, 28, 36, 45};

typedef struct Hotel {
	char name[1024];
	uint64_t date_start, date_end, id;
	uint64_t occupancy[3];
} Hotel;

static char *date_to_str_(uint64_t date, unsigned int buffer_id) {
	static char buffer[2][12];
	const struct tm *t = gmtime(&date);
	sprintf(buffer[buffer_id], "%04u-%02u-%02u", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
	return buffer[buffer_id];
}

static char *date_to_str(uint64_t date) {
	return date_to_str_(date, 0);
}

static uint64_t parse_date(char *buffer) {
	struct tm t;
	bzero(&t, sizeof(t));
	if(sscanf(buffer, "%4d-%2d-%2d", &t.tm_year, &t.tm_mon, &t.tm_mday) != 3)
		return 0;
	t.tm_year -= 1900;
	t.tm_mon -= 1;
	return mktime(&t);
}

static MYSQL_RES *query(const char *fmt, ...) {
	//parse format
	char buf[512];
	va_list args;
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);

	if(!mysql_query(con, buf))
		return mysql_store_result(con);

	printf("Err: %s\n", mysql_error(con));
	//mysql_close(con);
	//exit(1);
}

static my_ulonglong insert(const char *fmt, ...) {
	//parse format
	char buf[512];
	va_list args;
	va_start(args, fmt);
	vsnprintf(buf, sizeof(buf), fmt, args);
	va_end(args);

	if(!mysql_query(con, buf))
		return mysql_insert_id(con);

	printf("Err: %s\n", mysql_error(con));
	//mysql_close(con);
	//exit(1);
}

static char *quote(char *input) {
	unsigned long length = strlen(input);
	char *output = malloc((length * 2) + 1);
	mysql_real_escape_string(con, output, input, length);
	return output;
}

static uint64_t search_hotel(char *hotelname, Hotel *result, uint64_t min_id) {
	char *tmp = quote(hotelname);
	MYSQL_RES *res = query("SELECT id, name, occupancy, date_begin, date_end FROM hotels WHERE name LIKE '%s' AND id >= %" PRIu64 ";", tmp, min_id);
	free(tmp);
	my_ulonglong rows = mysql_num_rows(res);
	if(rows) {
		MYSQL_ROW row = mysql_fetch_row(res);
		unsigned long *lengths = mysql_fetch_lengths(res);
		result->id = strtoull(row[0], NULL, 10);
		strcpy(result->name, row[1]);
		memcpy(result->occupancy, row[2], lengths[2]);
		result->date_start = parse_date(row[3]);
		result->date_end = parse_date(row[4]);
	}
	mysql_free_result(res);
	return rows;
}

static void save_booking(char *email, uint64_t hotel_id, uint64_t arrival_date, uint64_t los, uint64_t adults, uint64_t children, uint64_t infants) {
	char *tmp = quote(email);
	insert("INSERT INTO orders (email, hotel, arrival, los, adults, children, infants) VALUES ('%s', %" PRIu64 ", '%s', %" PRIu64 ", %" PRIu64 ", %" PRIu64 ", %" PRIu64 ");", tmp, hotel_id, date_to_str(arrival_date), los, adults, children, infants);
	free(tmp);
}

static void read_text(char *buffer) {
	while(1) {
		uint64_t res = read(0, buffer,  1024);
		if(res <= 0)
			break;
		buffer += res;
		if(!buffer[-1])
			return;
		if(buffer[-1] != '\n')
			continue;
		buffer[-1] = 0;
		return;
	}
}

static uint64_t read_number() {
	char buffer[1024];
	read_text(buffer);
	uint64_t res;
	if(sscanf(buffer, "%" PRIu64, &res) != 1)
		res = 0;
	return res;
}

static uint64_t read_date() {
	char buffer[1024];
	read_text(buffer);
	return parse_date(buffer);
}

static bool check_occupancy(uint64_t *occ, uint64_t adults, uint64_t children, uint64_t infants) {
	const unsigned int bit_index = OFFSETS_A[adults] + OFFSETS_CI[children + infants] + children;
	return 1 & (occ[bit_index / 64] >> (bit_index % 64));
}

int main(int argc, char **argv) {
	bool completed = false;
	char hotelname[1024];
	char email[1024];
	uint64_t arrival, los, adults, children, infants;
	Hotel hotel;

	if(argc < 2) {
		printf("Usage %s <mysql-password>\n", argv[0]);
		exit(1);
	}
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setenv("TZ", "UTC", 1);
	if(!(con = mysql_init(NULL))) {
		printf("Err: %s\n", mysql_error(con));
		exit(1);
	}
	if(!mysql_real_connect(con, "localhost", "booking", argv[1], "booking", 0, NULL, 0)) {
		printf("Err: %s\n", mysql_error(con));
		mysql_close(con);
		exit(1);
	}
	for(char *p = argv[1]; *p; p++)
		*p = 0;

	STEP1:
	completed = false;
	printf("Please enter the Hotelname you are interested in, you can use %% as wildcard:\n> ");
	while(1) {
		read_text(hotelname);
		switch(search_hotel(hotelname, &hotel, 0)) {
		case 0:
			printf("A hotel with this name is not available. Please try another:\n> ");
			continue;
		case 1:
			break;
		default:
			printf("There are multiple hotels with this name.\n");
			while(1) {
				printf("Do you want to stay in %s? Type 1:\n> ", hotel.name);
				if(read_number() == 1)
					break;
				if(!search_hotel(hotelname, &hotel, hotel.id + 1)) {
					printf("No other hotel available with this name.\n");
					goto STEP1;
				}
			}
		}
		break;
	}
	printf("Your hotel is %s.\n", hotel.name);

	STEP2:
	printf("The hotel is available from %s to %s, when do you want to arrive?\n> ", date_to_str(hotel.date_start), date_to_str_(hotel.date_end, 1));
	while(1) {
		arrival = read_date();
		if(arrival >= hotel.date_start && arrival <= hotel.date_end)
			break;
		printf("Sorry, the hotel is not available at the given date, enter another date:\n> ");
	}

	STEP3:
	printf("How long do you want to stay?\n> ");
	while(1) {
		los = read_number();
		if(((hotel.date_end - arrival) / DAYS_TO_SECONDS) >= los)
			break;
		printf("Sorry, the hotel is not available for this length of stay, please enter another length of stay:\n> ");
	}
	if(completed)
		goto DONE;

	STEP4:
	while(1) {
		printf("For how many adults do you want to book?\n> ");
		adults = read_number();
		printf("For how many children do you want to book?\n> ");
		children = read_number();
		printf("For how many infants do you want to book?\n> ");
		infants = read_number();
		if((adults + children + infants) > 8) {
			printf("Sorry, this booking system can only handle up to 8 persons.\n");
			continue;
		}
		if(check_occupancy(hotel.occupancy, adults, children, infants))
			break;
		printf("Sorry, this occupancy is not available in this hotel.\n");
	}
	completed = true;
	DONE:
	printf("Congratulations, all information is collected, please verify the data you entered:\n1) Hotel %s\n2) Arrival on %s\n3) Length of stay: %" PRIu64 " nights\n4) %" PRIu64 " adults, %" PRIu64 " children and %" PRIu64 " infants\n\nIs this information correct? Enter the number of the information you would like to change or type 0:\n> ", hotel.name, date_to_str(arrival), los, adults, children, infants);
	switch(read_number()) {
	case 1:  goto STEP1;
	case 2:  goto STEP2;
	case 3:  goto STEP3;
	case 4:  goto STEP4;
	default: break;
	}

	printf("Please enter the email address you want to be informed about details for your Booking:\n> ");
	read_text(email);

	save_booking(email, hotel.id, arrival, los, adults, children, infants);
	printf("You will shortly receive an email with the best offer we can find for your request.\nGoodbye.\n");
	return 0;
}


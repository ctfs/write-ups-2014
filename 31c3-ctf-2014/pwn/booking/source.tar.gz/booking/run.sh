#!/bin/sh
exec socat TCP-LISTEN:1234,reuseaddr=1,fork EXEC:"/service db-password",setgid=1000,setuid=1000,chroot=/home/user/chroot

#!/bin/sh

gcc -std=gnu99 -o maze -s -O3 maze.c -fno-stack-protector -fno-omit-frame-pointer -mno-omit-leaf-frame-pointer

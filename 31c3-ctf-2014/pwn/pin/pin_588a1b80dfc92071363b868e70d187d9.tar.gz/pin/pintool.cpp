#include "pin.H"
#include <stdlib.h>
#include <sys/mman.h>

char is_protected[4096] __attribute__ ((aligned (4096))) = {};

VOID check_syscall(ADDRINT rax) {
    switch(rax) {
    case 0: // sys_read
    case 1: // sys_write
    case 2: // sys_open
    case 3: // sys_close
    case 60: // sys_exit
        //always allowed
        break;

    case 37: // sys_alarm
        //enables protected mode
        if(!*is_protected) {
            *is_protected = 1;
            if(mprotect(is_protected, 4096, PROT_READ))
                exit(-1);
            break;
        }
        //fallthrough

    default:
        //syscalls which are forbidden in protected mode
        if(*is_protected)
            exit(-1);
    }
}

VOID insert_hooks(INS ins, VOID *val) {
    if(INS_IsSyscall(ins))
        INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)check_syscall, IARG_REG_VALUE, REG_RAX, IARG_END);
}

int main(int argc, char *argv[]) {
    if(PIN_Init(argc,argv))
        return 1;

    INS_AddInstrumentFunction(insert_hooks, NULL);
    PIN_StartProgram();

    return 0;
}

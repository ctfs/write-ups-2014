#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/mman.h>

static const char shellcode_footer[10] = {0x48, 0x31, 0xc0, 0xb0, 0x3c, 0x48, 0x31, 0xff, 0x0f, 0x05};

void handle(void) {
	#define SHELLCODE_LEN 4096
	#define SHELLCODE_USER_LEN (SHELLCODE_LEN - sizeof(shellcode_footer))
	char *shellcode = mmap(0, SHELLCODE_LEN, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	if(!shellcode) {
		printf("Unable to allocate memory.\n");
		return;
	}
	printf("Please input your shellcode, max %lu bytes, terminate with 8*0x90.\n", SHELLCODE_USER_LEN);
	unsigned int pos = 0;
	while(1) {
		ssize_t len = read(0, shellcode + pos, SHELLCODE_USER_LEN - pos);
		if(len <= 0)
			break;
		pos += len;
		if(pos >= SHELLCODE_USER_LEN)
			break;
		if(pos < 8)
			continue;
		if(0x9090909090909090 == *(uint64_t*)(shellcode + pos - 8))
			break;
	}
	memcpy(shellcode + pos, shellcode_footer, sizeof(shellcode_footer));
	printf("Running your %u bytes long shellcode.\n", pos);
	alarm(30);
	typedef void (*FP)(void);
	((FP)shellcode)();
}

int main() {
	int sock, client;
	signal(SIGCHLD, SIG_IGN);
	{
		int tmp = 1;
		struct sockaddr_in serv_addr;
		bzero((char *)&serv_addr, sizeof(serv_addr));
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(1234);
		serv_addr.sin_addr.s_addr = inet_addr("0.0.0.0");
		sock = socket(AF_INET, SOCK_STREAM, 0);
		setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*)&tmp, sizeof(tmp));
		bind(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
		listen(sock, 5);
	}
	while(1) {
		client = accept(sock, NULL, NULL);
		if(client < 0)
			continue;
		if(!fork())
			break;
		close(client);
	}
	dup2(client, 0);
	dup2(client, 1);
	dup2(client, 2);
	close(sock);
	close(client);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	handle();
}

#!/usr/bin/env python2
import re

"""

DIRTY solver!

needs an .c export from ida hexrays and .asm export (exported.c and exported.asm) parses the files and porduces the call order, this order is executed with gdb afterwards

prior to export, some things have to be reversed in ida:
- name array call_order (contains 1024 function pointers)
- the first function that is called in one of the referenced functions has to be named shifter
- the array with 320 entries that has its first element or'ed in most of the referenced functions has to be named call_order
- the array with 320 entries that is compared with the call_order array within the main function has to be named wanted_call_order

"""


f=file("exported.c").read().split("\r\n")

funcs = {}
should_add = False
for l in f:
	m = re.match(r"^\s*call_order[[]0[]] [|]= (0x[0-9A-F]+|[0-9]+)u;$", l)
	if m:
		n = eval(m.group(1))
		continue
	m = re.match(r"^(void|int) __cdecl sub_([0-9A-F]+)[(][)]$", l)
	if m:
		if should_add:
			funcs[n] = func_addr
		func_addr = int(m.group(2), 16)
		n = 0
		should_add = False
		continue
	m = re.match(r"^\s*shifter[(][)];$", l)
	if m:
		should_add = True
		continue
if should_add:
	funcs[n] = func_addr




f=file("exported.asm").read().split("\r\n")
num = 0
for i, l in enumerate(f):
	if l.startswith("call_order_wanted "):
		x = 0
		for l in f[i:i+320]:
			i = "0x"+(re.match(r"^.*\s+dd ([0-9A-F]+)h(\s+;.*|)$", l).group(1).lstrip("0").lower())
			assert(i == hex(int(i, 16)).replace("L",""))
			num |= int(i, 16) << x
			x += 32
		break

wanted_call_order = []
for _ in xrange(1024):
	wanted_call_order.append(num % 1024)
	num /= 1024
func_call_order = [funcs[i] for i in wanted_call_order[::-1]]
for f in func_call_order:
	print "call (0x%08x)()" % f


"""
use like this:

- start gdb with the file, the following commands are for gdb:
shell ./solver.py > gdb_script.gdb
break *0x08048819
commands
set $eip = 0x0804882f
source gdb_script.gdb 
cont
end
r
"""

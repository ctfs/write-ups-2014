#!/bin/sh
g++ -m32 challenge.cpp -O3 -o challenge -s -fopenmp

#!/bin/sh
g++ numeric.cpp -O3 -onumeric -lgmpxx -lgmp -s

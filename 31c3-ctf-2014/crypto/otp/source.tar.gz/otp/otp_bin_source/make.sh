#!/bin/sh
g++ otp_gen.cpp -o otp.bin

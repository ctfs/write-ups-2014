#!/usr/bin/env python2
import tornado.ioloop
import tornado.web
import sqlite3
import hashlib
import struct
import json
import os
import re
import subprocess

def sql(q, *args):
    cur = db.cursor()
    #print q, args
    cur.execute(q, args)
    r = cur.fetchall()
    #print r
    return r

def check_tokens(username, tokens, signature):
    username = username.encode("utf8")
    signature = signature.encode("utf8")
    args = ["static/otp.bin", "-v", signature, username]
    for _, secret, sequence in tokens:
        args += ["%d" % (sequence + 1), "%d" % (sequence + 10), str(secret).encode("hex")]
    try:
        token, sequence = (int(i) for i in re.match("^ok:([0-9]+):([0-9]+)$", subprocess.check_output(args)).groups())
        if username != "admin":
            sql("UPDATE tokens SET sequence = ? WHERE id = ?", sequence, tokens[token][0])
            db.commit()
        return True
    except:
        return False

def hash_password(password, seed):
    #print `password, seed`
    return sqlite3.Binary(hashlib.sha512(seed + password.encode("utf8")).digest())

def login(username, password, otp):
    if not username:
        return {"err": "enter username"}
    if len(username) >= 16:
        return {"err": "username too long"}
    if not re.match("^[0-9a-zA-Z]*$", username):
        return {"err": "username contains bad characters"}
    if not password:
        return {"err": "enter password"}
    records = sql("SELECT u.id, u.pwseed, u.pwhash, count(k.id) as tokens FROM users u LEFT JOIN tokens k ON u.id = k.user WHERE u.name = ?", username)
    assert(len(records) < 2)
    if not records:
        userid = None
    else:
        userid, pwseed, pwhash, tokens = records[0]
    if userid is None:
        pwseed = ""
        pwhash = ""
    if pwhash != hash_password(password, pwseed):
        return {"err": "username or password wrong"}
    if tokens and not otp:
        return {"err": "enter one time password"}
    if tokens:
        if not re.match("^[0-9a-fA-F]+$", otp):
            return {"err": "invalid one time password"}
        tokens = sql("SELECT id, secret, sequence FROM tokens WHERE user = ?", userid)
        if not check_tokens(username, tokens, otp):
            return {"err": "one time password wrong"}
    return {"user": userid}

def register(username, password):
    if not username:
        return {"err": "enter username"}
    if len(username) >= 16:
        return {"err": "username too long"}
    if not re.match("^[0-9a-zA-Z]*$", username):
        return {"err": "username contains bad characters"}
    if not password:
        return {"err": "enter password"}
    pwseed = sqlite3.Binary(os.urandom(16))
    pwhash = hash_password(password, pwseed)
    try:
        record = sql("INSERT INTO users (name, pwseed, pwhash) VALUES(?,?,?)", username, pwseed, pwhash)
    except:
        return {"err": "username already exists"}
    db.commit()
    return {}

class BaseHandler(tornado.web.RequestHandler):
    def get_current_user(self):
        u = self.get_secure_cookie("user")
        if u is None:
            return None
        try:
            return int(u)
        except:
            return None

    def is_admin(self):
        return self.current_user == admin

class HomeHandler(BaseHandler):
    def get(self):
        self.render("home.html", xsrf_token = self.xsrf_token)

class PasswordsHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        secrets = sql("SELECT id, site, password FROM secrets WHERE user = ?", self.current_user)
        self.render("passwords.html", secrets = secrets, xsrf_token = self.xsrf_token)

    def action_add(self, site, password):
        sql("INSERT INTO secrets (user, site, password) VALUES (?, ?, ?)", self.current_user, site, password)

    def action_del(self, id_):
        sql("DELETE FROM secrets WHERE id = ? AND user = ?", id_, self.current_user)

    def action_mod(self, id_, site, password):
        sql("UPDATE secrets SET site = ?, password = ? WHERE id = ? AND user = ?", site, password, id_, self.current_user)

    @tornado.web.authenticated
    def post(self):
        self.check_xsrf_cookie()
        if self.is_admin():
            raise tornado.web.HTTPError(500)
        actions = {
            u"add": (("site","password"), self.action_add),
            u"del": (("id",), self.action_del),
            u"mod": (("id", "site", "password"), self.action_mod),
        }
        action = self.get_argument("action")
        if action not in actions:
            raise tornado.web.HTTPError(500)
        args, action = actions[action]
        action(*(self.get_argument(arg) for arg in args))
        db.commit()

class TokenDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self, id_):
        id_ = int(id_)
        token = sql("SELECT u.name, t.secret, t.sequence FROM users u INNER JOIN tokens t ON u.id = t.user WHERE t.id = ? AND t.user = ?", id_, self.current_user)
        if not token:
            raise tornado.web.HTTPError(500)
        token, = token
        self.set_header('Content-Type', 'application/force-download')
        self.set_header('Content-Disposition', 'attachment; filename=token%d.bin' % id_)
        self.write(token[1] + struct.pack("Q", token[2]) + token[0].encode("utf8") + "\x00")
    
class SettingsHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        tokens = sql("SELECT id, date, sequence FROM tokens WHERE user = ?", self.current_user)
        self.render("settings.html", tokens = tokens, xsrf_token = self.xsrf_token)

    def action_add(self):
        secret = sqlite3.Binary(os.urandom(8))
        sql("INSERT INTO tokens (user, secret) VALUES (?, ?)", self.current_user, secret)

    def action_del(self, id_):
        sql("DELETE FROM tokens WHERE id = ? AND user = ?", id_, self.current_user)

    @tornado.web.authenticated
    def post(self):
        self.check_xsrf_cookie()
        if self.is_admin():
            raise tornado.web.HTTPError(500)
        actions = {
            u"token_add": ((), self.action_add),
            u"token_del": (("id",), self.action_del),
        }
        action = self.get_argument("action")
        if action not in actions:
            raise tornado.web.HTTPError(500)
        args, action = actions[action]
        action(*(self.get_argument(arg) for arg in args))
        db.commit()

class RegisterHandler(BaseHandler):
    def post(self):
        self.check_xsrf_cookie()
        username = self.get_argument("username", "")
        password = self.get_argument("password", "")
        r = register(username, password)
        self.write(json.dumps(r))

class LoginHandler(BaseHandler):
    def post(self):
        self.check_xsrf_cookie()
        username = self.get_argument("username", "")
        password = self.get_argument("password", "")
        otp = self.get_argument("otp", "")
        r = login(username, password, otp)
        if "err" not in r:
            self.set_secure_cookie("user", str(r["user"]))
        self.write(json.dumps(r))

def make_sure_admin_exists():
    global admin
    #admin Sup3r&sEc\_/re_p@$$w()rd 9ae684ca583214d33905000000000000fd635dded0bbb40e162da79fba55ae32
    register("admin", "Sup3r&sEc\\_/re_p@$$w()rd")
    admin = sql("SELECT id FROM users WHERE name = 'admin'")[0][0]
    sql("DELETE FROM tokens WHERE user = ?", admin)
    sql("INSERT INTO tokens (user, secret, sequence) VALUES (?,?,?)", admin, sqlite3.Binary("93c10e438c99bb49".decode("hex")), 1337)
    sql("DELETE FROM secrets WHERE user = ?", admin)
    sql("INSERT INTO secrets (user, site, password) VALUES (?,?,?)", admin, u"flag", u"31C3_a7e3683344e954efd8a58a2a3da7fbe8")
    print "admin user is:", `admin`

def main():
    global db
    db = sqlite3.connect("db/db.sqlite")
    sql("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT UNIQUE, pwseed BLOB NOT NULL, pwhash BLOB NOT NULL)")
    sql("CREATE TABLE IF NOT EXISTS tokens (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user INTEGER NOT NULL, date INTEGER NOT NULL DEFAULT (date('now')), secret BLOB NOT NULL, sequence INTEGER NOT NULL DEFAULT 0)")
    sql("CREATE TABLE IF NOT EXISTS secrets (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, user INTEGER NOT NULL, site TEXT NOT NULL, password TEXT NOT NULL)")
    make_sure_admin_exists()
    settings = {
        "login_url": "/",
        "static_path": "static/",
        "template_path": "templates/",
        "cookie_secret": "ymNLNBVVqzAsFYGA6C2ORRoSHEXUSzS1ohKfV7aU9dyYudyf1A+QVel3RuVCEMI6no6kzcVp5J9v",
        "debug": False,
    }
    application = tornado.web.Application([
        (r"/", HomeHandler),
        (r"/passwords", PasswordsHandler),
        (r"/settings", SettingsHandler),
        (r"/settings/token([0-9]+).bin", TokenDownloadHandler),
        (r"/login", LoginHandler),
        (r"/register", RegisterHandler),
        (r"/static", RegisterHandler),
    ], **settings)
    application.listen(8000)
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()

<?
	include "config.php";
	include "common.php";

	$common = new common;

	$id = trim($_POST['id']);
	$password = sha1($_POST['password']);

	$userpw = $common->getpasswd($id);

	if($userpw != "" && $userpw == $password){
		$salt = file_get_contents("../../long_salt.txt");
		$login_time = mktime();

		setcookie("login_time",$login_time);
		setcookie("user_name",$id);
		setcookie("hash",hash('crc32', $salt.'|'.$login_time.'|'.$id));

		echo "<script>window.location = 'index.php';</script>";
	}else{
		echo "Login Fail";
	}
?>
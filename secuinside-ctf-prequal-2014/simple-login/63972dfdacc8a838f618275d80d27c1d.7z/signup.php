<?
	include "config.php";
	include "common.php";

	$common = new common;

	include "recaptcha-php-1.11/recaptchalib.php";

	$resp = null;
	$error = null;
?>
<html>
	<head>
		<title>::: Signup</title>
		<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
	</head>

	<body style="background-color:#fffaf0">
		<div style="width:500px;height:300px;margin-top:300px;margin-left:auto;margin-right:auto;">
			<h2 class=text-center>Signup</h2>
			<form class="form-horizontal" role="form" action="signup_ok.php" method=post>
			  <div class="form-group">
			    <label class="col-sm-2 control-label">ID</label>
			    <div class="col-sm-10">
			      <input type="text" class="form-control" name="id" id="inputID" placeholder="ID">
			    </div>
			  </div>
			  <div class="form-group">
			    <label for="inputPassword" class="col-sm-2 control-label">Password</label>
			    <div class="col-sm-10">
			      <input type="password" class="form-control" name="password" id="inputPassword" placeholder="Password">
			    </div>
			  </div>
			  <div class="form-group">
			    <label for="inputPassword2" class="col-sm-2 control-label">Password Repeat</label>
			    <div class="col-sm-10">
			      <input type="password" class="form-control" name="password2" id="inputPassword2" placeholder="Password Repeat">
			    </div>
			  </div>
			  <div class="form-group">
			    <label for="inputPassword2" class="col-sm-2 control-label">Captcha</label>
			    <div class="col-sm-10">
			      <?=recaptcha_get_html($publickey, $error);?>
			    </div>
			  </div>
			  <div class="form-group">
			    <div class="col-sm-offset-2 col-sm-10">
			      <button type="submit" class="btn btn-default">Sign up</button>
			    </div>
			  </div>
			</form>
		</div>
	</body>
</html>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
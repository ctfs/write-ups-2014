<?
	include "config.php";
	include "common.php";

	$common = new common;

	include "recaptcha-php-1.11/recaptchalib.php";

	$resp = null;
	$error = null;

	if (!empty($_POST["recaptcha_response_field"])) {
        	$resp = recaptcha_check_answer ($privatekey,
                                        	$_SERVER['REMOTE_ADDR'],
                                        	$_POST['recaptcha_challenge_field'],
	                                        $_POST['recaptcha_response_field']);

        	if (!$resp->is_valid) {
                //exit("Wrong Captcha");
        	} 
	}else{
		//exit("Empty Captcha");
	}
	// Check Captcha


	$id = strtolower(trim($_POST[id]));
	$password = $_POST[password];
	$password2 = $_POST[password2];


	if(empty($id) || empty($password) || empty($password2)){
		exit("empty info");
	}

	if( preg_match("/[^0-9A-Za-z]/", $id) ){
	 	exit("cannot be used Special character");
	}
	// Check id

	if (strlen($id) > 20){
		exit("id is too long");
	}

	if( $common->getidx($id) ){
		exit("Duplicate ID");
	}

	if($password != $password2){
		exit("password confirm is not equal to your password");
	}

	$password = sha1($password);

	if($common->insertmember($id, $password)){
		echo "<script>window.location = './';</script>";
	}
?>


<?
	include "config.php";
	include "common.php";

	$common = new common;

	if($common->islogin()){
		if($common->isadmin())	$f = "Flag is : ".__FLAG__;
		else $f = "Hello, Guest!";

		echo <<<EOF
			<html>
				<head>
					<title>::: Hello</title>
					<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
				</head>

				<body style="background-color:#fffaf0">
					<div style="width:500px;height:300px;margin-top:300px;margin-left:auto;margin-right:auto;">
						<h2 class=text-center>Hello</h2>
						<div class=text-center> {$_COOKIE['user_name']} Logined <br /> {$f} </div>
					</div>
				</body>
			</html>

			<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
EOF;
	}else{
		include "login.htm";
	}
?>
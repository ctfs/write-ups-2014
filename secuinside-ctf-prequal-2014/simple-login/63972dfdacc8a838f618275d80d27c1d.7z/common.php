<?
	class common{
		public function getidx($id){
			$id = mysql_real_escape_string($id);
			$info = mysql_fetch_array(mysql_query("select idx from member where id='".$id."'"));
			return $info[0];
		}

		public function getpasswd($id){
			$id = mysql_real_escape_string($id);
			$info = mysql_fetch_array(mysql_query("select password from member where id='".$id."'"));
			return $info[0];
		}

		public function islogin(){
			if( preg_match("/[^0-9A-Za-z]/", $_COOKIE['user_name']) ){
	 			exit("cannot be used Special character");
			}

			if( $_COOKIE['user_name'] == "admin" )	return 0;

			$salt = file_get_contents("../../long_salt.txt");

			if( hash('crc32',$salt.'|'.(int)$_COOKIE['login_time'].'|'.$_COOKIE['user_name']) == $_COOKIE['hash'] ){
				return 1;
			}

			return 0;
		}

		public function autologin(){

		}

		public function isadmin(){
			if( $this->getidx($_COOKIE['user_name']) == 1){
				return 1;
			}

			return 0;
		}

		public function insertmember($id, $password){
			$id = mysql_real_escape_string($id);
			mysql_query("insert into member(id, password) values('".$id."', '".$password."')") or die();

			return 1;
		}
	}
?>
